<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bopper
 */

use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<script src="https://cmp.osano.com/AzqL3LT24EJ7AO41/da105e87-72d8-4eb8-9bd0-2f0590586bd9/osano.js"></script>
	<?php if ( is_page( 'contact-us' ) ): ?>
		<script>
			dataLayer = [{
				'event': 'formSubmission',
				'eventCategory': 'form',
				'eventAction': 'Contact Sales',
				'eventLabel': 'Contact'
			}];
		</script>
	<?php endif; ?>
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-NWLQSMD');</script>
	<!-- End Google Tag Manager -->
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'site-wrapper no-js' ); ?>>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NWLQSMD"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	<?php wp_body_open(); ?>

	<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', THEME_TEXT_DOMAIN ); ?></a>
	<?php
	$background_check_link = get_field('background_check_link', 'option');
	$client_login_link = get_field('client_login_link', 'option');
	$site_logo        = get_field( 'site_logo', 'option' );
	$wrapper_classes  = 'site-header w-100';
	$wrapper_classes .= $site_logo ? ' has-logo' : '';
	$wrapper_classes .= has_nav_menu( 'primary' ) || has_nav_menu( 'mobile' ) ? ' has-menu' : '';
	?>
	<header id="masthead" class="<?php echo esc_attr( $wrapper_classes ); ?> main-header" role="banner">
		<?php
		if ( ! empty( $background_check_link ) || ! empty( $client_login_link ) ) { ?>
			<div class="top-links">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="top-links-inner">
								<?php
								if ( ! empty( $background_check_link ) ) {
									print_element( 'anchor', [
										'text'  => $background_check_link['title'],
										'href'  => $background_check_link['url'],
										'class' => 'background-check-icon',
									] );
								}

								if ( ! empty( $client_login_link ) ) {
									print_element( 'anchor', [
										'text'  => $client_login_link['title'],
										'href'  => $client_login_link['url'],
										'class' => 'client-login-icon',
									] );
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
		<div class="container position-relative">
			<div class="row align-items-center">
				<div class="col-9 col-lg-2">
					<div class="site-branding header-logo">
						<?php if ( $site_logo ) : ?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
								<img src="<?php echo wp_get_attachment_image_url( $site_logo, 'medium' ); ?>" class="logo" width="177" height="51" alt="Go back to home page"/>
							</a>
						<?php else: ?>
							<p class="site-title">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
							</p>
						<?php endif; ?>
					</div><!-- .site-branding -->
				</div>

				<div class="col-3 col-lg-10">
					<?php if ( has_nav_menu( 'primary' ) || has_nav_menu( 'mobile' ) ) : ?>
						<button type="button" class="off-canvas-open bar-icon d-block d-lg-none" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open Menu', THEME_TEXT_DOMAIN ); ?>">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					<?php endif; ?>
					<div class="header-navigation-outer">
						<nav id="site-navigation" class="main-navigation navigation-menu d-none d-lg-flex justify-content-end" aria-label="<?php esc_attr_e( 'Main Navigation', THEME_TEXT_DOMAIN ); ?>">
							<?php
							wp_nav_menu( [
								'theme_location' => 'primary',
								'menu_id'        => 'primary-menu',
								'menu_class'     => 'menu dropdown d-flex justify-content-end',
								'container'      => false,
								'fallback_cb'    => false,
							] );
							?>
							<div class="d-flex align-items-center">
								<?php
								$buttons = get_field('header_buttons','option');
								if ( $buttons ) :
									$buttons['class'] = [ 'common-btn' ];
									print_module(
										'buttons-group',
										$buttons
									);
								endif;

								$links = get_field('links','option');
								if ( $links):
									?>
									<div class="header-links">
										<?php
										foreach ( $links as $link ) :
											$link_url   = $link['link']['url'];
											$link_title = $link['link']['title'];

											echo '<a href="' . $link_url . '">' . $link_title . '</a>';
										endforeach;
										?>
									</div>
								<?php endif; ?>
							</div>
						</nav><!-- #site-navigation -->
					</div>
				</div>
			</div>
		</div><!-- .container -->
	</header><!-- #masthead -->