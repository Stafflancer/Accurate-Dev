<?php
/**
 * Functions and definitions.
 *
 * @link    https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package bopper
 * @since   1.0.0
 */

/**
 * Define theme globals: theme version, text domain, etc.
 *
 * @since 1.0.0
 */
$theme_version  = wp_get_theme()->get( 'Version' );
$version_string = is_string( $theme_version ) ? $theme_version : null;

define( 'THEME_VERSION', $version_string );
define( 'THEME_ROOT_PATH', trailingslashit( get_template_directory() ) );
define( 'THEME_ROOT_URL', trailingslashit( get_template_directory_uri() ) );
define( 'THEME_TEXT_DOMAIN', 'sensiba' );

/*
 * Check if the WordPress version is 6.0 or higher, and if the PHP version is at least 7.4.
 * If not, do not activate.
 */
if ( version_compare( $GLOBALS['wp_version'], '6.0', '<' ) || version_compare( PHP_VERSION_ID, '70400', '<' ) ) {
	require( 'inc/compatibility.php' );

	return;
}

/**
 * Check to see if ACF Pro is active. Give a warning message if not.
 *
 * @since  1.0
 */
require( 'inc/dependency.php' );

/**
 * Get all the include files for the theme.
 *
 * @return void
 */
function include_inc_files() {
	$files = [
		'inc/functions/', // Custom functions that act independently of the theme templates.
		'inc/hooks/', // Load custom filters and hooks.
		'inc/setup/', // Theme setup.
		'inc/helpers/', // Includes helper files.
		'inc/shortcodes/', // Load shortcodes.
		'inc/template-tags/', // Custom template tags for this theme.
		'inc/acf/acf.php', // Theme ACF setup and blocks.
		'inc/optimization.php', // Optimize theme performance. Must load last to avoid conflicts.
	];

	foreach ( $files as $include ) {
		$include = trailingslashit( THEME_ROOT_PATH ) . $include;

		// Allows inclusion of individual files or all .php files in a directory.
		if ( is_dir( $include ) ) {
			foreach ( glob( $include . '*.php' ) as $file ) {
				require $file;
			}
		} else {
			require $include;
		}
	}
}

include_inc_files();

add_filter( 'gform_required_legend', function( $legend, $form ) {
    return '* indicates required fields';
}, 10, 2 );


function filter_input_object( $input_object, $sfid ) {
	if ( 10318 === $sfid ) {
		
		// ensure we are only filtering the correct field name - in this case the field we want to filter has the name `_sft_faq_type`
		// we also want to make sure its a `select` input type we're filtering
		if ( ( $input_object['name'] != '_sft_faq_type' ) || ( $input_object['type'] != 'radio' ) ) {
			return $input_object;
		}

		// if we want to filter the options generated, we need to make sure the options variable actually exists before proceeding (its only available to certain field types)
		if ( ! isset( $input_object['options'] ) ) {
			return $input_object;
		}

		// now we know there are options we can loop through each one, and change what we need
		foreach ( $input_object['options'] as $option ) {
			if ( $option->value == '' ) {
				//the option with no value is always the "all items" or unselected state
				$option->label = 'All FAQs';
			} elseif ( $option->value == 'accel-background-check' || $option->value == 'ace-background-check' || $option->value == 'accurate-background-check' ) {
				$option->label = 'My Background Check';
			} elseif ( $option->value == 'accel-client' || $option->value == 'ace-client' || $option->value == 'accurate-client' ) {
				$option->label = 'Client';
			}
		}		
	}

	return $input_object;
}

add_filter( 'sf_input_object_pre', 'filter_input_object', 10, 2 );


/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function accurate_widgets_init() {
	register_sidebar( array(
		'name' => esc_html__( 'Keep the good work', 'accurate' ),
		'id'   => 'good-work',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'CTA side image block', 'accurate' ),
		'id'   => 'cta-side-image',
	) );
	register_sidebar( array(
		'name' => esc_html__( 'CTA Connect', 'accurate' ),
		'id'   => 'cta-connect',
	) );
}

add_action( 'widgets_init', 'accurate_widgets_init' );