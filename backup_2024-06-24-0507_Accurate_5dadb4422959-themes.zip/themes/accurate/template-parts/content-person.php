<?php
/**
 * Template part for displaying post.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'medium' );
$thumbnail      = ! empty( $post_thumbnail[0] ) ? $post_thumbnail[0] : get_theme_file_uri( '/assets/images/placeholder-square.jpg' );

?>
<section class="inner-banner bg-primary-bright-blue text-white section-padding">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-12 m-auto">
				<div class="text-block text-white text-center">
					<div class="people-img">
						<div class="img">
							<img src="<?php echo esc_url( $thumbnail ); ?>" alt="Picture of <?php the_title(); ?>">
						</div>
						<div class="left-shape-img"></div>
						<div class="right-shape-img"></div>
					</div>
					<h2><?php the_title(); ?></h2>
					<p><?php the_field( 'title' ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="people-single-content">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-12 m-auto">
				<div class="content">
					<?php the_content(); ?>
					<div class="back-link">
						<a href="/25years/people/">Back to Our People</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>