<?php
/**
 * Template part for displaying post.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_post_author;
use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_entry_footer;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_global_design_options;

$categories = get_the_terms( get_the_ID(), 'category' );
$exclude = get_the_ID();
if($categories){
	$category_id = array();
	foreach( $categories as $category ) {
		$category_id[] = $category->term_id;
	}
}

$author_name    = get_field('author_name');
$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'medium' );
$thumbnail      = ! empty( $post_thumbnail[0] ) ? $post_thumbnail[0] : get_theme_file_uri( '/assets/images/placeholder-square.jpg' );

$u_time          = get_the_time( 'U' );
$u_modified_time = get_the_modified_time( 'U' );
// Only display modified date if 24hrs have passed since the post was published.
if ( $u_modified_time >= $u_time + 86400 ) {
	$show_latdate = true;
}
else{
	$show_latdate = false;
}
?>
<section class="add-to-any-social">
	<?php echo do_shortcode( '[addtoany]'); ?>
</section>
<section class="inner-banner bg-primary-bright-blue text-white section-padding">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-4 text-center mb-4 mb-md-0 wow fadeIn animated" data-wow-delay="0.25s">
				<img class="circle single-post-view-img" width="270px" height="270px" src="<?php echo esc_url( $thumbnail ); ?>" alt="Featured Image - <?php the_title(); ?>">
			</div>
			<div class="col-md-8">
				<div class="section-heading wow fadeIn" data-wow-delay="0.50s">
					<h1 class="h2"><?php the_title(); ?></h1>
					<div><span class="time">Date Published: <?php the_time( 'F d, Y' ); echo " | ";?><?php if($show_latdate){ ?> Last Updated:<?php the_modified_time('F d, Y');  echo " | "; }?></span> <span class="author"><?php echo "By "; the_author(); ?></span></div>
				</div>
			</div>
		</div>
	</div>
</section>

<article id="post" class="single-post-content">
	<section class="single-post section-padding">
		<div class="container">
			<a href="/blog/" class="readlink"><i class="fa fa-angle-left"></i> Back to all posts</a>
			<div class="row mt-4">
				<div class="col-md-4 wow fadeIn" data-wow-delay="0.25s">
					<div class="blog-sidebar">
						<div class="widget related-post">
							<h4 class="widget-title">RELATED TOPICS:</h4>
							<ul class="list-unstyled mb-0">
								<?php
								$categories = get_categories();
								foreach ( $categories as $key => $value ) {
									?>
									<li><a href="<?php echo get_category_link( $value->term_id ); ?>"><?php echo $value->name; ?></a></li>
								<?php } ?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-8 wow fadeIn" data-wow-delay="0.50s">
					<div class="post-content">
						<?php
							the_content(
								sprintf(
									wp_kses(
									/* translators: %s: Name of current post. Only visible to screen readers */
										esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', THEME_TEXT_DOMAIN ),
										[
											'span' => [
												'class' => [],
											],
										]
									),
									the_title( '<span class="screen-reader-text">"', '"</span>', false )
								)
							);

							wp_link_pages(
								[
									'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXT_DOMAIN ),
									'after'  => '</div>',
								]
							);
							?>
					</div>
				</div>
			</div>

			<nav class="pagination justify-content-between mt-5 pb-3 wow fadeIn" data-wow-delay="0.25s">
				<?php previous_post_link( '%link', '&laquo; Previous', true ); ?>
				<?php next_post_link( '%link', 'Next &raquo;', true ); ?>
			</nav>
			<?php
			$news     = array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => '3',
				'post__not_in'   => array( get_the_ID() ),
			);
			$my_query = new WP_Query( $news );
			if($my_query->have_posts()){
				?>
				<div class="latest-post text-center mt-4">
					<div class="section-heading  mt-5 wow fadeIn" data-wow-delay="0.25s">
						<h2 class="mb-0">Latest Posts</h2>
					</div>
					<div class="row row-cols-1 row-cols-md-3">
						<?php
						while ( $my_query->have_posts() ) {
							$my_query->the_post();
							$post_id        = get_the_ID();
							$post_date      = get_the_date();
							$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'post_resize_image' );
							$post_image     = $post_thumbnail[0];

							if ( empty( $post_image ) ) {
								$post_image = get_theme_file_uri( '/assets/images/placeholder-square.jpg' );
							}
							?>
							<div class="col wow fadeIn mt-5" data-wow-delay="0.25s">
								<a href="<?php the_permalink(); ?>">
									<img class="circle" width="170px" height="170px" src="<?php echo esc_url( $post_image ); ?>" alt="">
									<h3 class="mt-4 h4">
										<?php the_title(); ?> <i class="fa fa-angle-right text-secondary-pink font-size-16"></i>
									</h3>
								</a>
							</div>
						<?php
						}
						wp_reset_postdata();
						?>
					</div>
				</div>
			<?php } ?>
		</div>
	</section>
</article>