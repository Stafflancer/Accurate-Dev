<?php
/**
 * Template part for displaying post.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_post_author;
use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_entry_footer;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_global_design_options;

$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'medium' );
$thumbnail      = ( ! empty( $post_thumbnail[0] ) ) ? $post_thumbnail[0] : get_theme_file_uri( '/assets/images/placeholder-square.jpg' );
?>
<section class="inner-banner bg-primary-bright-blue text-white section-padding">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-4 text-center mb-4 mb-md-0 wow fadeIn animated" data-wow-delay="0.25s">
				<img class="circle single-post-view-img" src="<?php echo esc_url( $thumbnail ); ?>" alt="Featured Image - <?php the_title(); ?>" width="270px" height="270px">
			</div>
			<div class="col-md-8">
				<div class="section-heading wow fadeIn" data-wow-delay="0.50s">
					<h1 class="h2"><?php the_title(); ?></h1>
					<?php if ( get_field( 'date' ) ): ?>
						<p><?php the_time( 'F d, Y' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="single-post section-padding single-hawaii-content">
	<div class="container">
		<a href="/ban-the-box/" class="readlink"><i class="fa fa-angle-left"></i> Back to Ban the Box</a>
		<div class="row mt-4">
			<!-- <div class="col-md-4 wow fadeIn" data-wow-delay="0.25s">
				<div class="blog-sidebar">
					<div class="widget related-post">
						<h4><?php the_field( 'the_basics_title' ); ?></h4>
						<?php the_field( 'the_basics' ); ?>
					</div>
				</div>
			</div> -->
			<div class="col-md-12 wow fadeIn" data-wow-delay="0.50s">
				<div class="post-content">
					<?php the_content(); ?>
				</div>
			</div>
		</div>
	</div>
</section>