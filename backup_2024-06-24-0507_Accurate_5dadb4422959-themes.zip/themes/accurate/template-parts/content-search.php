<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */
?>
<div class="result-post-type">
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'container' ); ?>>
		<div class="post-result-data"><?php
			if(get_post_type( get_the_ID() ) == 'post'){ 
				$global_post_type = 'Insights';
			} 
			else if(get_post_type( get_the_ID() ) == 'page'){
				$global_post_type = 'Page';
			}
			else if(get_post_type( get_the_ID() ) == 'resource'){
				$global_post_type = 'Resource';
			} 
			else if(get_post_type( get_the_ID() ) == 'news'){
				$global_post_type = 'News';
			}  
			else if(get_post_type( get_the_ID() ) == 'tribe_events'){
				$global_post_type = 'Events';
			}
			else if(get_post_type( get_the_ID() ) == 'review'){
				$global_post_type = 'Review';
			}
			else if(get_post_type( get_the_ID() ) == 'leader'){
				$global_post_type = 'Leaders';
			}
			else if(get_post_type( get_the_ID() ) == 'locations'){
				$global_post_type = 'Location';
			}
			else{
				$global_post_type = 'Post';
			} ?>
			<header class="entry-header">
				<h5 class="text-color-green"><?php echo $global_post_type; ?></h5>
				<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
			</header><!-- .entry-header -->

			<div class="entry-summary">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->
		</div>
	</article><!-- #post-<?php the_ID(); ?> -->
</div>