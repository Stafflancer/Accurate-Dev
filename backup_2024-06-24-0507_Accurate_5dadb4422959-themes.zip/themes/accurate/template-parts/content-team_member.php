<?php
/**
 * Template part for displaying team member.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_global_team_design_options;
use function BopDesign\bopper\print_svg;

$cta_buttons = get_field( 'cta_buttons', 'option' );
$linkedin    = get_field( 'linkedin', get_the_ID() );

if ( ! empty( $cta_buttons['section_header'] ) || ! empty( $cta_buttons['buttons'] ) ) {
	wp_enqueue_style( 'cta-subscribe', get_theme_file_uri( '/blocks/cta-buttons/cta-buttons.css' ), [], null );
	$class_name       = array();
	$container_class  = array();
	$block_classes    = array();
	$background_image = '';

	if ( ! empty( $cta_buttons['design']['background_image'] ) ) {
		$background_image = ' has-background image-as-background';
	}

	if ( ! empty( $cta_buttons['design']['text_color'] ) ) {
		$block_classes[] = 'has-text-' . $cta_buttons['design']['text_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $cta_buttons['design']['tagline_color'] ) ) {
		$block_classes[] = 'has-tagline-' . $cta_buttons['design']['tagline_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $cta_buttons['design']['heading_color'] ) ) {
		$block_classes[] = 'has-heading-' . $cta_buttons['design']['heading_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $cta_buttons['design']['background_color']['color_picker'] ) ) {
		$block_classes[] = 'has-background ';
		$block_classes[] = 'has-' . $cta_buttons['design']['background_color']['color_picker'] . '-background-color ';
	}

	$container_class = join( ' ', [
		$cta_buttons['design']['container_size'],
		'z-9',
	] );

	if ( $cta_buttons['design']['margin_top'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $cta_buttons['design']['margin_top'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $cta_buttons['design']['margin_top'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $cta_buttons['design']['margin_top'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $cta_buttons['design']['margin_top'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( $cta_buttons['design']['margin_bottom'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $cta_buttons['design']['margin_bottom'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $cta_buttons['design']['margin_bottom'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $cta_buttons['design']['margin_bottom'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $cta_buttons['design']['margin_bottom'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( $cta_buttons['design']['padding_top'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $cta_buttons['design']['padding_top'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $cta_buttons['design']['padding_top'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $cta_buttons['design']['padding_top'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $cta_buttons['design']['padding_top'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( $cta_buttons['design']['padding_bottom'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $cta_buttons['design']['padding_bottom'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $cta_buttons['design']['padding_bottom'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $cta_buttons['design']['padding_bottom'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $cta_buttons['design']['padding_bottom'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( ! empty( $cta_buttons['design']['column_size'] ) ) :
		$column_size_class = 'col-12 col-md-' . $cta_buttons['design']['column_size'] . ' col-sm-' . $cta_buttons['design']['column_size'] . '';
	endif;

	$column_class = join( ' ', [
		$column_size_class,
	] );

	$row_class = join( ' ', [
		'row ',
	] );
}

$role = get_field( 'role', get_the_ID() );
?>
<article id="post-<?php the_ID(); ?>">
	<div class="single-team-member-outer">
		<div class="single-team-member-profile">
			<div class="container">
				<div class="row justify-content-between">
					<div class="col-lg-3 col-md-4 col-sm-12">
						<div class="single-team-member-inner">
							<?php print_post_thumbnail( 'medium_large' ); ?>
						</div>
						<div class="social-icon-link">
							<?php if ( $linkedin ) { ?>
								<a href="<?php echo esc_url( $linkedin ); ?>"
								   class="social-icon d-flex align-items-center">
									<?php
									print_svg( [
										'icon'   => 'linkedin',
										'width'  => '18',
										'height' => '20',
									] );
									?>
								</a>
							<?php } ?>
						</div>
					</div>
					<div class="col-lg-8 col-md-8 col-sm-12">
						<div class="single-team-member-head">
							<header class="entry-header">
								<?php
								if ( is_singular() ) :
									the_title( '<h1 class="entry-title">', '</h1>' );
								else :
									the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
								endif;
								?>
							</header><!-- .entry-header -->
							<?php
							if ( get_field( 'role' ) ) :
								print_element( 'content', [
									'content' => get_field( 'role' ),
									'class'   => [ 'company-name', 'post-excerpt', 'm-0' ],
								] );
							endif;
							?>
						</div>
						<div class="single-team-member-text detail-first-paragraph">
							<div class="entry-content">
								<?php
								the_content( sprintf( wp_kses( /* translators: %s: Name of current post. Only visible to screen readers */ esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', THEME_TEXT_DOMAIN ), [
									'span' => [
										'class' => [],
									],
								] ), the_title( '<span class="screen-reader-text">"', '"</span>', false ) ) );

								wp_link_pages( [
									'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXT_DOMAIN ),
									'after'  => '</div>',
								] );
								?>
							</div>
						</div><!-- .entry-content -->
						<div class="card-links">
							<?php
							print_element( 'anchor', [
								'text'  => 'Connamara Leadership',
								'href'  => get_the_permalink( 285 ),
								'class' => 'back-link-btn',
							] );
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php if ( ! empty( $cta_buttons['section_header'] ) || ! empty( $cta_buttons['buttons'] ) ) : ?>
			<section class="acf-block cta-buttons position-relative overflow-hidden <?php echo implode( ' ', $block_classes ) . ' ' . $background_image . ' alignfull  ' . implode( ' ', $class_name ); ?>">
				<?php print_global_team_design_options( $cta_buttons['design'] ); ?>
				<div class="<?php echo esc_attr( $container_class ); ?>">
					<div class="<?php echo esc_attr( $row_class ); ?> justify-content-center">
						<div class="<?php echo esc_attr( $column_class ); ?>">
							<div class="content-hero-banner"><?php
								// Section Header.
								if ( ! empty( $cta_buttons['section_header'] ) ) :
									print_module( 'section-header', $cta_buttons['section_header'] );
								endif; ?>
							</div>
						</div>
					</div>
					<?php
					// buttons
					if ( $cta_buttons['buttons'] ) :
						$buttons          = $cta_buttons['buttons'];
						$buttons['class'] = [ 'home-hero-banner-btn', 'justify-content-center', 'mt-5' ];
						print_module( 'buttons-group', $buttons );
					endif;
					?>
				</div>
			</section>
		<?php endif; ?>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->