<?php
/**
 * Template part for displaying post.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_post_author;
use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_entry_footer;
use function BopDesign\bopper\print_element; 
use function BopDesign\bopper\print_module; 
use function BopDesign\bopper\print_global_design_options; 

$post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'post_resize_image' );
?>
<section class="side-image-wrap side-image-left-half-wrap inner-banner bg-accent-light-blue text-white section-padding">
	<div class="container">
		<div class="row">
			<div class="side-image left">
				<img src="<?php echo get_stylesheet_directory_uri()?>/assets/images/right.png" alt="Hero banner">
			</div>
			<div class="col-md-8 offset-md-4">
				<div class="section-heading">
	                <strong class="text-secondary-pink">
	                	<?php
							$terms = wp_get_post_terms( get_the_ID(), 'news_type' );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
								$taxonomy = $terms[0]->name;
								echo $taxonomy;
							}
						?>
	                </strong> <br /> <br />
					<h1 class="h2 text-primary-bright-blue"><?php the_title(); ?></h1>
				</div>
				<div class="press-header mb-0 mt-4">
	                <!--<span class="text-primary-navy d-block mt-1"><?php the_author(); ?> | <?php echo get_the_date('M d, Y'); ?></span>-->
	            </div>
			</div>
		</div>
	</div>
</section>

<section class="single-post section-padding">
    <div class="container">
		<div class="row mt-4">
		    <div class="col-md-8 wow fadeIn offset-md-4" data-wow-delay="0.25s">
				<div class="post-content">
				    <?php the_content(); ?>
				</div>
		    </div>
		</div>

		<div class="latest-post news-post text-center mt-5">
		    <div class="section-heading mt-5 wow fadeIn"  data-wow-delay="0.25s">
				<h2 class="mb-0">Recent News</h2>
		    </div>
		    <div class="news-press-listing">
			    <ul class="list-unstyled large-icon-list row row-cols-1 row-cols-md-3 justify-content-between press-post text-left">
				    <?php
				    $news     = array(
					    'post_type'      => 'news',
					    'post_status'    => 'publish',
					    'posts_per_page' => '3',
					    'post__not_in'   => array( get_the_ID() ),
				    );
				    $my_query = new WP_Query( $news );

					while ( $my_query->have_posts() ) : $my_query->the_post();
					?>
						 <li class="col mt-5 wow fadeInUp" data-wow-delay="0.25s">
							<a class="d-block" href="<?php echo get_the_permalink(); ?>">
					            <div class="press-header mb-3">
					                <strong class="text-secondary-pink">
					                	<?php
											$terms = wp_get_post_terms( get_the_ID(), 'news_type' );
											if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
												$taxonomy = $terms[0]->name;
												echo $taxonomy;
											}
										?>
					                </strong>
					                <span class="text-primary-navy d-block mt-1 font-weight-light"><?php the_author(); ?> | <?php echo get_the_date('M d, Y'); ?></span>
					            </div>
							    <h3 class="mb-2 h4"><?php the_title(); ?> <i class="fa fa-angle-right text-secondary-pink font-size-16"></i></h3>
							</a>
					    </li>
				    <?php
					endwhile;
					wp_reset_postdata();
					?>
				</ul>
			</div>
		</div>
    </div>
</section>