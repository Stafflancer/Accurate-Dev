<?php
/**
 * Returns an array of classes from a block's Gutenberg fields.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Returns an updated array of classes.
 *
 * @param array $block Array of block attributes.
 *
 * return array The updated array of classes.
 */
function get_block_classes( $block, $design_option ) {

	// Setup defaults.
	$block_defaults = [
		'full_height'    => false,
		'align'          => 'full',
		'margin_top'     => 'none',
		'margin_bottom'  => 'none',
		'padding_top'    => 'medium',
		'padding_bottom' => 'medium',
	];
	$block_attrs    = [];
	$block_classes = [];

	// Get block desgin options.
	if ( empty( $design_option ) ) {
		$design_option = get_design_options( $block['id'] );
	}

	if ( ! empty( $block['className'] ) ) :
		$block_classes[] = $block['className'];
	endif;

	if ( ! empty( $block['backgroundColor'] ) ) {
		$block_classes[] = 'has-background';
		$block_classes[] = 'has-' . $block['backgroundColor'] . '-background-color';
	}

	if ( ! empty( $design_option['text_color'] ) ) {
		$block_classes[] = 'has-text-' . $design_option['text_color']['color_picker'] . '-color';
	}

	if ( ! empty( $design_option['tagline_color'] ) ) {
		$block_classes[] = 'has-tagline-' . $design_option['tagline_color']['color_picker'] . '-color';
	}

	if ( ! empty( $design_option['heading_color'] ) ) {
		$block_classes[] = 'has-heading-' . $design_option['heading_color']['color_picker'] . '-color';
	}

	if ( ! empty( $design_option ) ) {
		if ( ! empty( $design_option['background_type'] ) ) {
			switch ( $design_option['background_type'] ) {
				case 'color':
					$block_classes[]  = 'has-background';
					$block_classes[]  = 'color-as-background';

					if ( $design_option['background_color']['color_picker'] ) {
						$background_color = $design_option['background_color']['color_picker'];
						$block_classes[]  = 'has-' . esc_attr( $background_color ) . '-background-color';
					}
					break;
				case 'gradient':
					$block_classes[]  = 'has-background';
					$block_classes[]  = 'gradient-as-background';

					if ( $design_option['gradient'] ) {
						$background_color = $design_option['gradient'];
						$block_classes[]  = 'has-' . esc_attr( $background_color ) . '-background-gradient';
					}
					break;
				case 'image':
				case 'video':
					$block_classes[] = 'has-background';
					$block_classes[] = $design_option['background_type'] . '-as-background';

					if ( ! empty( $design_option['has_parallax'] ) && $design_option['has_parallax'] ) {
						$block_classes[] = 'has-parallax';
					}
					break;
				case 'none':
				default:
					$block_classes[] = 'no-background';
			}
		}
	}

	if ( ! empty( $block['full_height'] ) && $block['full_height'] ) {
		$block_attrs['full_height'] = $block['full_height'];
	}

	if ( ! empty( $block['align'] ) ) {
		$block_attrs['align'] = $block['align'];
	} elseif ( empty( $block['align'] ) || '' === $block['align'] ) {
		$block_attrs['align'] = 'none';
	}

	if ( ! empty( $design_option ) ) {
		// Set top/bottom margin for the block.
		if ( ! empty( $design_option['margin_top'] ) ) {
			$block_attrs['margin_top'] = $design_option['margin_top'];
		}

		if ( ! empty( $design_option['margin_bottom'] ) ) {
			$block_attrs['margin_bottom'] = $design_option['margin_bottom'];
		}

		// Set top/bottom padding for the block.
		if ( ! empty( $design_option['padding_top'] ) ) {
			$block_attrs['padding_top'] = $design_option['padding_top'];
		}

		if ( ! empty( $design_option['padding_bottom'] ) ) {
			$block_attrs['padding_bottom'] = $design_option['padding_bottom'];
		}
	}

	$block_attrs = wp_parse_args( $block_attrs, $block_defaults );
	foreach ( $block_attrs as $attr => $value ) {
		$block_classes[] = get_class_name_by_attribute( $attr, $value );
	}

	return $block_classes;
}