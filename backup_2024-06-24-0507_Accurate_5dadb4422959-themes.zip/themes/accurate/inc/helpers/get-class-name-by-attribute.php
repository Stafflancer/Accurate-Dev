<?php
/**
 * Returns the class value of the attribute.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

function get_class_name_by_attribute( string $attr, $value = '' ) {
	$allowed_attributes = [
		'full_height'    => false,
		'align'          => 'full',         // none | wide | full
		'align_text'     => 'left',         // left | center | right
		'align_content'  => 'top left',     // [top|center|bottom left|center|right]
		'margin_top'     => 'extra-small',         // none | small | medium | large
		'margin_bottom'  => 'extra-small',         // none | small | medium | large
		'padding_top'    => 'extra-small',       // none | small | medium | large
		'padding_bottom' => 'extra-small',       // none | small | medium | large
		'container_size' => 'container',    // container | container-fluid
		'column_size'    => 'full',         // auto | 4 - 11 | full
		'animation'      => 'none',         // none | animate.css classes (fadeIn | slideIn | zoomInUp | etc.)
	];

	if ( ! array_key_exists( $attr, $allowed_attributes ) ) {
		return '';
	}

	$class_name = '';

	switch ( $attr ) {
		case 'full_height':
			if ( ! empty( $value ) && $value ) {
				$class_name = 'vh-100';
			}
			break;
		case 'align':
			if ( empty( $value ) || 'none' === $value ) {
				$class_name = 'alignnone';
			} else {
				$class_name = 'align' . esc_attr( $value );
			}
			break;
		case 'align_text':
			switch ( $value ) {
				case 'center':
					$class_name = 'text-center';
					break;
				case 'right':
					$class_name = 'text-end';
					break;
				case 'left':
				default:
					$class_name = 'text-start';
					break;
			}
			break;
		/*case 'align_content':
			switch ( $value ) {
				case 'top':
					$class_name = 'self-start is-position-' . sanitize_title( $value );
					break;
				case 'center':
					$class_name = 'self-center is-position-' . sanitize_title( $value );
					break;
				case 'bottom':
					$class_name = 'self-end is-position-' . sanitize_title( $value );
					break;
				case 'top left':
					$class_name = 'align-items-start justify-content-start is-position-' . sanitize_title( $value );
					break;
				case 'top center':
					$class_name = 'align-items-start justify-content-center is-position-' . sanitize_title( $value );
					break;
				case 'top right':
					$class_name = 'align-items-start justify-content-end is-position-' . sanitize_title( $value );
					break;
				case 'center left':
					$class_name = 'align-items-center justify-content-start is-position-' . sanitize_title( $value );
					break;
				case 'center center':
					$class_name = 'align-items-center justify-content-center is-position-' . sanitize_title( $value );
					break;
				case 'center right':
					$class_name = 'align-items-center justify-content-end is-position-' . sanitize_title( $value );
					break;
				case 'bottom left':
					$class_name = 'align-items-end justify-content-start is-position-' . sanitize_title( $value );
					break;
				case 'bottom center':
					$class_name = 'align-items-end justify-content-center is-position-' . sanitize_title( $value );
					break;
				case 'bottom right':
					$class_name = 'align-items-end justify-content-end is-position-' . sanitize_title( $value );
					break;
				default:
					$class_name = 'align-items-start justify-content-start is-position-top-left';
					break;
			}
			break;*/
		case 'container_size':
			$container_classes = ' position-relative z-10 inner-container';
			$class_name = esc_attr( $value ) . $container_classes;
			break;
		case 'column_size':
			switch ( $value ) {
				case '6':
					$class_name = 'col-12 col-md-6';
					break;
				case '7':
					$class_name = 'col-12 col-md-7';
					break;
				case '8':
					$class_name = 'col-12 col-md-8';
					break;
				case '9':
					$class_name = 'col-12 col-md-9';
					break;
				case '10':
					$class_name = 'col-12 col-md-10';
					break;
				case '11':
					$class_name = 'col-12 col-md-11';
					break;
				case '12':
				default:
					$class_name = 'col-12';
					break;
			}
			break;
		case 'margin_top':
			switch ( $value ) {
				case 'extra-small':
					$class_name = 'margin-top-extra-small';
					break;
				case 'small':
					$class_name = 'margin-top-small';
					break;
				case 'medium':
					$class_name = 'margin-top-medium';
					break;
				case 'large':
					$class_name = 'margin-top-large';
					break;
				case 'extra-large':
					$class_name = 'margin-top-extra-large';
					break;
				case 'none':
				default:
					$class_name = 'mt-0';
					break;
			}
			break;
		case 'margin_bottom':
			switch ( $value ) {
				case 'extra-small':
					$class_name = 'margin-bottom-extra-small';
					break;
				case 'small':
					$class_name = 'margin-bottom-small';
					break;
				case 'medium':
					$class_name = 'margin-bottom-medium';
					break;
				case 'large':
					$class_name = 'margin-bottom-large';
					break;
				case 'extra-large':
					$class_name = 'margin-bottom-extra-large';
					break;
				case 'none':
				default:
					$class_name = 'mb-0';
					break;
			}
			break;
		case 'padding_top':
			switch ( $value ) {
				case 'extra-small':
					$class_name = 'padding-top-extra-small';
					break;
				case 'small':
					$class_name = 'padding-top-small';
					break;
				case 'medium':
					$class_name = 'padding-top-medium';
					break;
				case 'large':
					$class_name = 'padding-top-large';
					break;
				case 'extra-large':
					$class_name = 'padding-top-extra-large';
					break;
				case 'none':
				default:
					$class_name = '';
					break;
			}
			break;
		case 'padding_bottom':
			switch ( $value ) {
				case 'extra-small':
					$class_name = 'padding-bottom-extra-small';
					break;
				case 'small':
					$class_name = 'padding-bottom-small';
					break;
				case 'medium':
					$class_name = 'padding-bottom-medium';
					break;
				case 'large':
					$class_name = 'padding-bottom-large';
					break;
				case 'extra-large':
					$class_name = 'padding-bottom-extra-large';
					break;
				case 'none':
				default:
					$class_name = '';
					break;
			}
			break;
		case 'animation':
			// If we have an animation set a class.
			switch ( $value ) {
			case 'none':
					$class_name = 'none';
					break;
			case 'none':
			default:
				$class_name = 'wow animate__animated animate__' . $value;
				break;
			}
			break;
	}

	return $class_name;
}