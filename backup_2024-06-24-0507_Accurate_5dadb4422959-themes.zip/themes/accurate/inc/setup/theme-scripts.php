<?php
/**
 * Setup theme scripts and styles.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Enqueue scripts and styles.
 *
 * @return void
 */
function scripts() {
	/**
	 * Enqueue 3rd party required styles.
	 */
	wp_enqueue_style( 'bootstrap-grid', get_theme_file_uri( '/assets/css/vendor/bootstrap-grid.min.css' ), [], null );
	wp_enqueue_style( 'bootstrap-utilities', get_theme_file_uri( '/assets/css/vendor/bootstrap-utilities.min.css' ), [], null );
	wp_enqueue_style( 'animate-style', get_theme_file_uri( '/assets/css/vendor/animate.min.css' ), [], null );

	/**
	 * Enqueue theme required styles.
	 */
	wp_enqueue_style( 'bopper-menus-style', get_theme_file_uri( '/assets/css/menus.css' ), [], null );
	wp_enqueue_style( 'bopper-mobile-menu-style', get_theme_file_uri( '/assets/css/mobile-menu.css' ), [], null, '(max-width: 991px)' );
	wp_enqueue_style( 'bopper-off-canvas-style', get_theme_file_uri( '/assets/css/off-canvas.css' ), [], null, '(max-width: 991px)' );
	wp_enqueue_style( 'custom-main-style', get_theme_file_uri( '/assets/css/custom-main.css' ), [], null );

	/**
	 * Register scripts to use in templates and load only when needed.
	 */
	wp_register_style( 'swiperjs-style', get_theme_file_uri( '/assets/css/vendor/swiper-bundle.min.css' ), [], null );
	wp_register_script( 'swiperjs-script', get_theme_file_uri( '/assets/js/vendor/swiperjs/swiper-bundle.min.js' ), [], null, true );

	wp_register_style( 'modal-style', get_theme_file_uri( '/assets/css/modal.css' ), [], null );
	wp_register_script( 'modal-video-script', get_theme_file_uri( '/assets/js/modal-video.js' ), [], null, true );

	wp_register_style( 'odometer-theme-default-style', get_theme_file_uri( '/assets/css/vendor/odometer-theme-default.css' ), [], null );
	wp_register_script( 'odometer-script', get_theme_file_uri( '/assets/js/vendor/odometer/odometer.js' ), [], null, true );

	/**
	 * Enqueue required scripts.
	 */
	wp_enqueue_script( 'wow-script', get_theme_file_uri( '/assets/js/vendor/wow/wow.min.js' ), [], null, true );
	wp_enqueue_script( 'bopper-script', get_theme_file_uri( '/assets/js/main.js' ), [ 'wow-script' ], null, true );
	wp_enqueue_script( 'custom-script', get_theme_file_uri( '/assets/js/custom-script.js' ), ['jquery'], null, true );

	/**
	 * Register block script.
	 */
	wp_register_script( 'hero-banner-home-script', get_template_directory_uri() . '/blocks/hero-banner-home/hero-banner-home.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'stats-in-circles-script', get_template_directory_uri() . '/blocks/stats-in-circles/stats-in-circles.js', [ 'jquery', 'acf' ], null );
	wp_register_script( 'slider-timeline-cards-script', get_template_directory_uri() . '/blocks/slider-timeline-cards/slider-timeline-cards.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'logos-script', get_template_directory_uri() . '/blocks/logos/logos.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'latest-blog-posts-script', get_template_directory_uri() . '/blocks/latest-blog-posts/latest-blog-posts.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'side-by-side-script', get_template_directory_uri() . '/blocks/side-by-side/side-by-side.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'tabbed-content-script', get_template_directory_uri() . '/blocks/tabbed-content/tabbed-content.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'cta-testimonial-script', get_template_directory_uri() . '/blocks/cta-testimonial/cta-testimonial.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'slider-testimonials-script', get_template_directory_uri() . '/blocks/slider-testimonials/slider-testimonials.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'slider-our-growth-stories-script', get_template_directory_uri() . '/blocks/slider-our-growth-stories/slider-our-growth-stories.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'contact-info-script', get_template_directory_uri() . '/blocks/contact-info/contact-info.js', [ 'jquery', 'acf' ], null );
	wp_register_script( 'slider-upcoming-events-script', get_template_directory_uri() . '/blocks/slider-upcoming-events/slider-upcoming-events.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'faq-listing-script', get_template_directory_uri() . '/blocks/faq-listing/faq-listing.js', [ 'jquery', 'acf' ], null );
	wp_register_script( 'hero-banner-video-script', get_template_directory_uri() . '/blocks/hero-banner-video/hero-banner-video.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'press-kit-script', get_template_directory_uri() . '/blocks/press-kit/press-kit.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'hero-banner-partners-script', get_template_directory_uri() . '/blocks/hero-banner-partners/hero-banner-partners.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'single-stat-script', get_template_directory_uri() . '/blocks/single-stat/single-stat.js', [ 'jquery', 'acf' ], null );
	wp_register_script( 'my-background-check-links-script', get_template_directory_uri() . '/blocks/my-background-check-links/my-background-check-links.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'my-background-check-faqs-script', get_template_directory_uri() . '/blocks/my-background-check-faqs/my-background-check-faqs.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'history-and-evolution-script', get_template_directory_uri() . '/blocks/history-and-evolution/history-and-evolution.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'tabs-and-content-script', get_template_directory_uri() . '/blocks/tabs-and-content/tabs-and-content.js', [ 'jquery', 'acf' ] );
	wp_register_script( 'player-js', 'https://www.youtube.com/iframe_api', [ 'jquery', 'acf' ] );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_user_logged_in() ) {
		wp_enqueue_style( 'bopper-wp-admin-style', get_theme_file_uri( '/assets/css/wp-admin.css' ), [], null );
	}
}

add_action( 'wp_enqueue_scripts', __NAMESPACE__ . '\scripts' );