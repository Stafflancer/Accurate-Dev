<?php
/**
 * Inline Critical CSS.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Inline Critical CSS.
 */
function critical_css() {
	$critical_css_path = get_theme_file_path( '/assets/css/critical.css' );

	if ( file_exists( $critical_css_path ) ) :
		?>
		<style id="critical-css">
			<?php include $critical_css_path; ?>
		</style>
	<?php
	endif;
}

add_action( 'wp_head', __NAMESPACE__ . '\critical_css', 1 );
