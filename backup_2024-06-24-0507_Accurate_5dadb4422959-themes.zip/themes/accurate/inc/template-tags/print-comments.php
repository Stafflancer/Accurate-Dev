<?php
/**
 * Display the comments if the count is more than 0.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the comments if the count is more than 0.
 *
 * @author BopDesign
 */
function print_comments() {
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
}