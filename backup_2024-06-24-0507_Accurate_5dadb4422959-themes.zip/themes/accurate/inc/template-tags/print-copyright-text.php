<?php
/**
 * Echo the copyright text saved in the Customizer.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Echo the copyright text saved in the Customizer.
 *
 * @author BopDesign
 */
function print_copyright_text() {
	// Grab our copyright group from the theme settings.
	$copyright_data = get_field( 'copyright', 'option' );


	if ( ! empty( $copyright_data ) && is_array( $copyright_data ) ) :
		$copyright_text = '';

		if ( ! empty( $copyright_data['copyright_text'] ) ) :
			$copyright_text = ' ' . $copyright_data['copyright_text'];
		endif;

		if ( ! empty( $copyright_data['copyright_logos'] ) ) :?>
			<ul class="footer_copyrigt_logos"><?php 
			foreach($copyright_data['copyright_logos'] as $logos) :  
				if($logos) : ?>
					<li>
	                	<?php echo wp_get_attachment_image( $logos, 'full' ); ?>
	           	 	</li><?php
	           	endif;
           	endforeach; ?>
			</ul>
		<?php endif;?>

		<?php 
		$copyright_links = $copyright_data['copyright_links'];
		?>
		<div class="font-size-small">
			<span class="footer-copyright-text">&copy; <?php echo gmdate( 'Y' ); ?> <?php echo esc_html( $copyright_text ); ?></span>
			<?php
			if ( $copyright_links ):
				echo '<span class="footer-copyright-links">';
				foreach ( $copyright_links as $link ) :
					$link_url   = $link['link']['url'];
					$link_title = $link['link']['title'];

					echo '<span>&nbsp;|&nbsp;</span><a href="' . $link_url . '">' . $link_title . '</a>';
				endforeach;
				echo '</span>';
			endif;
			if ( ! empty( $copyright_data['copyright_footnote'] ) ) :
			?>
			<div class="footer_copyrigt_footnote">
				<?php echo $copyright_data['copyright_footnote']; ?>
			</div>
			<?php endif; ?>
		</div>
	<?php else: ?>
		<div class="font-size-small">&copy; <?php echo gmdate( 'Y' ) . ' ' . get_bloginfo( 'name' ); ?></div>
	<?php
	endif;
}