<?php
/**
 * Display the footer logos saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_footer_logos() {

	// header links
	$logos = get_field( 'logos', 'option' );
	if ( $logos):
		$image_class = 'footer-logos';
		echo '<div class="footer-logos">';
				foreach ( $logos as $logo ) :
					echo wp_get_attachment_image( $logo['logo'], 'large', array( 'class' => esc_attr( $image_class ) ) );
				endforeach;
		echo '</div>';
	endif;
	
}