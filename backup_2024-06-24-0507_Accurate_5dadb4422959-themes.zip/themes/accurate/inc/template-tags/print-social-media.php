<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_social_media() {
	// Create an array of our social links for ease of setup.
	// Change the order of the networks in this array to change the output order.
	$social_networks = get_field( 'social_media', 'option' );
	if ( ! empty( $social_networks ) && is_array( $social_networks ) ) :
		$count = count( $social_networks );
		?>
		<ul class="d-flex social-icons menu">
			<?php
			$i = 1;
			// Loop through our networks array.
			foreach ( $social_networks as $network) :
	
				// Only display the list item if a URL is set.
				if ( ! empty( $network['social_media_url'] ) ) :
					$icon_wrapper_class = ' me-2 me-lg-3';

					if ( $count === $i ) {
						$icon_wrapper_class = '';
					}
					?>
					<li class="<?php echo esc_attr( $icon_wrapper_class ); ?>">
						<a href="<?php echo esc_url( $network['social_media_url'] ); ?>" class="social-icon d-flex align-items-center justify-content-center rounded-circle <?php echo esc_attr( $network['social_media_url'] ); ?>" target="_blank">
							<?php if($network['icon_type'] == 'svgcode') :
								echo $network['svg_code'];
							else:
								$image_class = 'svg-image'; 
								echo wp_get_attachment_image( $network['social_icon_image'], 'full', array( 'class' => esc_attr( $image_class ) ) ); 
							endif; ?>
							<span class="screen-reader-text">
								<?php
								/* translators: the social network name */
								printf( esc_attr__( 'Link to %s', THEME_TEXT_DOMAIN ), ucwords( esc_html( $network['select_social_media'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
								?>
							</span>
						</a><!-- .social-icon -->
					</li><?php
					$i++;
				endif;
			endforeach;
			?>
		</ul><!-- .social-icons -->
	<?php endif;
}