<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_address() {
	$address = get_field( 'address', 'option' );
	if ( !empty( $address['address_title'] ) || !empty( $address['address'] )) {
		echo '<div class="address">';
		// Heading.
		if ( $address['address_title'] ) :
			print_element( 'heading', [
				'text'  => $address['address_title'],
				'level' => 5,
				'class' => [ 'address-title'],
			] );
		endif;
		echo $address['address'];
		echo '</div>';
	}
}