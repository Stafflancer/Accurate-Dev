<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_links() {

	// header links
	$footer_links = get_field( 'footer_links', 'option' );
	if ( $footer_links['links']):
		echo '<h5>'.$footer_links['heading'].'</h5>';
		echo '<span class="footer-links">';
				foreach ( $footer_links['links'] as $link ) :
					$link_url   = $link['link']['url'];
					$link_title = $link['link']['title'];

					echo '<a href="' . $link_url . '">' . $link_title . ' > </a>';
				endforeach;
		echo '</span>';
	endif;
	
}