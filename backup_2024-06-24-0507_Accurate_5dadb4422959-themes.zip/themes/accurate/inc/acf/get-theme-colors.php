<?php
/**
 * Get the theme colors for this project. Set these first in the theme.json and/or Sass partial,
 * then migrate them over here.
 *
 * @return array The array of our color names and hex values.
 */

namespace BopDesign\bopper;

function get_theme_colors() {
	$theme_colors    = [];
	$theme_json_file = get_theme_file_path( 'theme.json' );

	if ( file_exists( $theme_json_file ) ) {
		$theme_json_contents = file_get_contents( $theme_json_file );
		$theme_json_data     = json_decode( $theme_json_contents, true );

		if ( ! empty( $theme_json_data ) && ! empty( $theme_json_data['settings']['color']['palette'] ) ) {
			foreach ( $theme_json_data['settings']['color']['palette'] as $color ) {
				$color_name  = esc_html__( $color['name'], THEME_TEXT_DOMAIN );
				$color_value = $color['color'];

				$theme_colors[ $color_name ] = $color_value;
			}
		}

		if ( ! empty( $theme_colors ) ) {
			return $theme_colors;
		}
	}

	// If we are not using theme.json file, then setup theme colors here.
	return [
		esc_html__( 'Navy', THEME_TEXT_DOMAIN )    => '#003a70',
		esc_html__( 'Pink', THEME_TEXT_DOMAIN )  => '#ec008c',
		esc_html__( 'Dark Pink', THEME_TEXT_DOMAIN ) => '#d80080',
		esc_html__( 'Blue', THEME_TEXT_DOMAIN )   => '#1849b8',
		esc_html__( 'Light Blue', THEME_TEXT_DOMAIN ) => '#5fa3fb',
		esc_html__( 'Pale Blue 1', THEME_TEXT_DOMAIN )    => '#cfe3fd',
		esc_html__( 'Pale Blue 2 ', THEME_TEXT_DOMAIN )    => '#e7f1fe',
		esc_html__( 'Pale Blue 3 ', THEME_TEXT_DOMAIN )    => '#f1f7fe',
		esc_html__( 'Dark Gray', THEME_TEXT_DOMAIN )    => '#49587e',
		esc_html__( 'Medium Gray', THEME_TEXT_DOMAIN )    => '#7687a8',
		esc_html__( 'White', THEME_TEXT_DOMAIN )    => '#fff',
		esc_html__( 'Black', THEME_TEXT_DOMAIN )    => '#000'
	];
}


function get_theme_gradients() {
	$theme_colors    = [];
	$theme_json_file = get_theme_file_path( 'theme.json' );

	if ( file_exists( $theme_json_file ) ) {
		$theme_json_contents = file_get_contents( $theme_json_file );
		$theme_json_data     = json_decode( $theme_json_contents, true );

		if ( ! empty( $theme_json_data ) && ! empty( $theme_json_data['settings']['color']['gradients'] ) ) {
			foreach ( $theme_json_data['settings']['color']['gradients'] as $color ) {
				$color_name  = esc_html__( $color['name'], THEME_TEXT_DOMAIN );
				$color_value = $color['gradient'];

				$theme_colors[ $color_name ] = $color_value;
			}
		}

		if ( ! empty( $theme_colors ) ) {
			return $theme_colors;
		}
	}

	// If we are not using theme.json file, then setup theme colors here.
	return [
		esc_html__( 'Horizontal Blue', THEME_TEXT_DOMAIN )    => 'linear-gradient(318deg, #003a70 0%, #1849b8 100%)',
		esc_html__( 'Vertical Blue', THEME_TEXT_DOMAIN )    => 'linear-gradient(90deg, #0C255C, #1849B8)',
		esc_html__( 'Vertical Blue to Light', THEME_TEXT_DOMAIN )    => 'linear-gradient(180deg, rgba(241, 247, 254, 0.00) 0%, #F1F7FE 50.70%, rgba(241, 247, 254, 0.00) 100%)',
	];
}