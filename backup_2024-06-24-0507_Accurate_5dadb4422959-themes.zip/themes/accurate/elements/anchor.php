<?php
/**
 * ELEMENT: Anchor
 *
 * Elements are analogous to 'Atoms' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#atoms
 *
 * @package bopper
 */

use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$bopper_defaults = [
	'class'  => [ 'acf-element', 'acf-element-anchor' ],
	'text'   => false,
	'href'   => false,
	'target' => false,
];

$bopper_args = get_formatted_args( $args, $bopper_defaults );

// Make sure element should render.
if ( $bopper_args['href'] && $bopper_args['text'] ) :
	// Set up element attributes.
	$bopper_atts = get_formatted_atts( [ 'href', 'target', 'class' ], $bopper_args );
	?>
	<a <?php echo $bopper_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_html( $bopper_args['text'] ); ?></a>
<?php endif; ?>