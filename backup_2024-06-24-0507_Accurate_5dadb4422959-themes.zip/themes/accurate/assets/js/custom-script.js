jQuery(document).ready(function($)
{
	$(".custom-btn-new").click(function() {
		$('.client-form').css('display', 'block');
    	$('html,body').animate({
        scrollTop: $(".client-form").offset().top-180},
        800);
    	$('.client-form').fadeIn(100);
	});

	if ($(".clone-heading").hasClass("accent-position-left")) {
  		jQuery('.accent-position-left').parents().find('div:first.row').addClass('left-side-line-added');
	}
	jQuery(".common-popup").click(function($) {
		var href = jQuery(this).attr('href');
		console.log(href);
		if(href == '#' || href == 'javascript:;'){
		  var finded = jQuery(this).attr('id');
		  jQuery('.'+finded).show(); 
		  jQuery('body').addClass('modal-open');
		}
	});

	jQuery(".cross-btn").click(function($) {
	  var finded = jQuery(this).attr('data-id');
	  jQuery('.'+finded).hide(); 
	   jQuery('body').removeClass('modal-open');
	});

	jQuery(".menu-bar-mobile").click(function($) {
	  jQuery(this).toggleClass("open-menu");
	  jQuery(".header-navigation-outer").slideToggle();
	});
	jQuery(".header-search-icon").click(function($) {
	  jQuery(this).toggleClass("open-search-menu");
	  jQuery(".search-form").slideToggle();
	});
	
	// jQuery(".quick-links-main").hide();
		jQuery(".quick-links").click(function(){
			// jQuery(".quick-links").removeClass('kamal');
			$(this).toggleClass('open-buttons');
			jQuery(".quick-links-main").toggleClass('opened');
		});
	  
	  jQuery('.custom-select option').filter(function () {
		return jQuery(this).val() == jQuery('.custom-number').val();
	}).attr('selected', true);

	jQuery('body').on('change', '.custom-select', function () {
		//var winWidth = jQuery(window).width();
		var selectedVal = jQuery(this).find('option:selected').attr('value');
		if(selectedVal != '') {
			//if(winWidth <= 990){
				var telLink = selectedVal.replace("-", "").replace("-", "").replace("-", "").replace("-", "").replace(" ", "").replace("(", "").replace("", "");
				jQuery('.international-tel-number').html(selectedVal);
				jQuery('.international-tel-number').attr("href","tel:"+telLink);
				// jQuery('.custom-number').val('');
			// } else {
			// 	jQuery('.international-tel-number').html('');
			// 	jQuery('.international-tel-number').attr("href","");
			// 	jQuery('.custom-number').val(selectedVal);
			// }
		} else {
			jQuery('.international-tel-number').html('');
			jQuery('.international-tel-number').attr("href","");
			// jQuery('.custom-number').val('');
		}
	});
	
});

function scrollNav() {
  jQuery('.quick-links-main-inner a').click(function($){
    jQuery(".active").removeClass("active");     
    jQuery(this).addClass("active");
    
    jQuery('html, body').stop().animate({
      scrollTop: jQuery(jQuery(this).attr('href')).offset().top-320
    }, 800);
    return false;
  });
}
scrollNav();

const divs = document.querySelectorAll('.mktoFormRow');

divs.forEach(div => {
  if (divs.innerHTML === '' || div.textContent === '') {
    div.remove();
  }
});

jQuery(document).ready(function($){
    $('.close').click(function(){      
        $('iframe').attr('src', $('iframe').attr('src'));
    });
});