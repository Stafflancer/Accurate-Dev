<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package bopper
 */

use function BopDesign\bopper\get_main_classes;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

get_header();
$single_partner_form = get_field( 'single_partner_form', 'option' );
$client_form         = get_field( 'client_form', 'option' );
$latest_content      = get_field( 'latest_content', 'option' );
?>
	<main id="main" class="<?php echo esc_attr( get_main_classes( [] ) ); ?>" role="main">
		<?php
		while ( have_posts() ) : the_post();
			get_template_part( 'template-parts/content', 'page' );
		endwhile; // End of the loop.
		?>
		<?php if ( ! empty( $single_partner_form ) ) { ?>
			<section class="partners-section-main">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<?php if ( ! empty( $single_partner_form['heading'] ) || ! empty( $single_partner_form['content'] ) ) : ?>
								<div class="row justify-content-center text-center">
									<div class="">
										<div class="section-header-outer">
											<?php
											// Heading
											if ( $single_partner_form['heading'] ) :
												print_module( 'heading', [
													$single_partner_form['heading'],
												] );
											endif;

											// Content.
											if ( ! empty( $single_partner_form['content'] ) ) :
												print_element( 'content', [
													'content' => $single_partner_form['content'],
												] );
											endif;
											?>
										</div>
									</div>
								</div>
							<?php endif; ?>
							<?php if ( ! empty( $single_partner_form['client_type_cards'] ) ) : ?>
								<div class="row gap-24 justify-content-center">
									<?php
									$animation_delay = 0;
									foreach ( $single_partner_form['client_type_cards'] as $client_type_cards ):
										echo '<div class="col-12 col-sm-6"> 
												<div class="client_type_cards-with-image-box">';
												if ( ! empty( $client_type_cards['card_image'] ) ) :
													$image_class = 'card-image';
													?>
													<figure class="card-image-img">
														<?php echo wp_get_attachment_image( $client_type_cards['card_image'], 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
													</figure>
												<?php endif; ?>
												<div class="client_type_cards-with-image-body">
													<div class="client_type_cards-with-image-text">
														<?php
														// Heading.
														if ( $client_type_cards['card_heading']  ) :
															print_element( 'heading', [
																'text'  => $client_type_cards['card_heading'] ,
																'level' => 4,
																'class' => [ 'card-title', 'h4' ],
															] );
														endif;
														?>
													</div>
													<?php if ( ! empty( $client_type_cards['card_button']['url'] ) ) { ?>
														<div class="is-style-outline">
															<a href="<?php echo $client_type_cards['card_button']['url']; ?>" class="custom-btn-new acf-element acf-element-button has-background has-outline-pink-color has-color-pink stretched-link">
																<?php echo $client_type_cards['card_button']['title']; ?>
															</a>
														</div>
													<?php } ?>
													<?php
													// if ( !empty($client_type_cards['card_button']) ) :
													// 	$button = $client_type_cards['card_button'];
													// 	$button['class'] = [ 'custom-btn-new stretched-link has-pink-background-color has-color-white'];
													// 	print_element( 'button', $button );
													// endif;
													?>
												</div>
												<?php
												echo '</div>
											</div>';
									endforeach;
									?>
								</div>
							<?php endif; ?>
						</div>
						<?php if ( ! empty( $client_form ) ) { ?>
							<div class="client-form" style="display: none;">
								<?php echo $client_form; ?>
							</div>
						<?php } ?>
					</div>
				</div>
			</section>
		<?php } ?>
		<?php if ( ! empty( $latest_content ) ) { ?>
			<section class="latest-content">
				<div class="container">
					<?php if ( ! empty( $latest_content['heading'] ) || ! empty( $latest_content['content'] ) ) { ?>
						<div class="row">
							<div class="">
								<div class="section-header-outer">
									<?php
									//	Heading
									if ( ! empty( $latest_content['heading'] ) ) :
										print_module( 'heading', [
											$latest_content['heading'],
										] );
									endif;

									// Content.
									if ( ! empty( $latest_content['content'] ) ) :
										print_element( 'content', [
											'content' => $latest_content['content'],
										] );
									endif;
									?>
								</div>
							</div>
						</div>
					<?php } ?>
					<?php if ( ! empty( $latest_content['uberflip_content'] ) ) { ?>
						<div class="row">
							<div class="col-12">
								<?php echo $latest_content['uberflip_content']; ?>
							</div>
						</div>
					<?php } ?>
				</div>
			</section>
		<?php } ?>
	</main><!-- #main -->
<?php
get_footer();