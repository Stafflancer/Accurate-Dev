<?php
/**
 * BLOCK: Latest Blog Posts
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'latest-blog-posts-' . $block['id'],
	'class'    => [ 'acf-block', 'latest-blog-posts', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'latest',
	'blog_posts',
	'button',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );

if ( !empty($block_content['heading'] ) || !empty($block_content['content']) || !empty($block_content['latest'] == 1) || !empty($block_content['blog_posts']) || !empty($block_content['button'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> ">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<?php if ( array_key_exists( "main_heading", $block_content['heading'] ) && ! empty( $block_content['heading']['main_heading'] ) || ! empty( $block_content['content'] ) ) : ?>
						<div class="section-header-outer">
							<?php
							//	Heading
							if ( ! empty( $block_content['heading'] ) ) :
								print_module( 'heading', [
									$block_content['heading'],
								] );
							endif;
							// Content.
							if ( ! empty( $block_content['content'] ) ) :
								print_element( 'content', [
									'content' => $block_content['content'],
								] );
							endif;
							?>
						</div>
					<?php endif; ?>
				</div>
				<div class="col-md-12 col-sm-12">
					<div class="slider-arrow-outer">
						<?php
						if ( $block_content['latest'] == 1 ) :
							$post  = array(
								'numberposts' => 6,
								'post_type'   => 'post',
								'orderby'     => 'date',
								'order'       => 'DESC',
							);
							$latest_post = get_posts( $post );
							if ( !empty( $latest_post ) ) :
								global $post;
								echo ' <div class="swiper latest-post-slider">
									<div class="swiper-wrapper">';
										foreach ( $latest_post as $post ) :
											setup_postdata( $post );
											echo '<div class="swiper-slide">';
												print_module( 'card-post', [] );
											echo '</div>';
										endforeach;
										wp_reset_postdata();
										echo '
									</div>
								</div>
								<div class="slider-arrows">
									<a href="javascript:" class="arrowbtn prev">
										<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
											<path d="M443.4,16.98h-7.788l-7.424,8.079,7.424,8.006H443.4l-7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
										</svg>
									</a>
									<a href="javascript:" class="arrowbtn next">
										<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
											<path d="M428.185,16.98h7.788l7.424,8.079-7.424,8.006h-7.788l7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
										</svg>
									</a>
								</div>';
							endif;
						else :
							if ( ! empty( $block_content['blog_posts'] ) ) :
								echo ' <div class="swiper latest-post-slider">
									<div class="swiper-wrapper">';
										global $post;
										foreach ( $block_content['blog_posts'] as $post ):
											setup_postdata( $post );
											echo '<div class="swiper-slide">';
											print_module( 'card-post', [] );
											echo '</div>';
										endforeach;
										wp_reset_postdata();
								echo '</div>
									</div>
									<div class="slider-arrows">
										<a href="javascript:" class="arrowbtn prev">
											<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
												<path d="M443.4,16.98h-7.788l-7.424,8.079,7.424,8.006H443.4l-7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
											</svg>
										</a>
										<a href="javascript:" class="arrowbtn next">
											<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
												<path d="M428.185,16.98h7.788l7.424,8.079-7.424,8.006h-7.788l7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
											</svg>
										</a>
									</div>';
							endif;
						endif; ?>
						<div class="d-flex justify-content-center mt-4">
							<?php
							if ( $block_content['button'] ) :
								$button = $block_content['button'];
								print_element( 'button', $button );
							endif;
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>