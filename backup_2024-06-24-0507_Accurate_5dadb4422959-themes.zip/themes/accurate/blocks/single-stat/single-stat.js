const elementIsVisibleInViewport = (el, partiallyVisible = false) => {
	const {top, left, bottom, right} = el.getBoundingClientRect();
	const {innerHeight, innerWidth} = window;
	return partiallyVisible
		? ((top > 0 && top < innerHeight) ||
			(bottom > 0 && bottom < innerHeight)) &&
		((left > 0 && left < innerWidth) || (right > 0 && right < innerWidth))
		: top >= 0 && left >= 0 && bottom <= innerHeight && right <= innerWidth;
};

jQuery(document).ready(function ($) {
	let $singleStatRows = document.querySelectorAll('.stats-row');

	$(window).scroll(function () {
		$singleStatRows.forEach(singleStatRow => {
			if (!singleStatRow.classList.contains('animated') && elementIsVisibleInViewport(singleStatRow)) {
				let stat = singleStatRow.querySelector('.single-stat-val'),
					num = stat.dataset.value;

				const od = new Odometer({
					auto: false,
					el: stat,
					format: '(,ddd).dd',
					duration: 3000,
					theme: 'default',
				});
				od.render();

				// Initiate animation.
				setTimeout(function () {
					od.update(num);
				}, 100);

				singleStatRow.classList.add('animated');
			}
		});
	});
});