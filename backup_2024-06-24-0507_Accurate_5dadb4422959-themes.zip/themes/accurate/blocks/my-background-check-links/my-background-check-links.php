<?php
/**
 * BLOCK: My Background Check Links
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'my-background-check-links-' . $block['id'],
	'class'    => [ 'acf-block', 'my-background-check-links', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'login_data',
	'dispute_data',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );

$row_class    = join( ' ', [
	'row justify-content-between',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );

if ( !empty($block_content['login_data']) || !empty($block_content['dispute_data']) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> z-10 position-relative">
			<div class="row"><?php
					if ( ! empty( $block_content['login_data'] ) ) : ?>
						<div class="<?php echo esc_attr( $row_class ); ?> gap-24 justify-content-center"><?php
								echo '<div class=""> <div class="pricing-card-box">'; ?>
										<div class="pricing-card-body">
											<div class="pricing-card-text"><?php
												// Heading.
												if ( $block_content['login_data']['heading'] ) :
													if ( $block_content['login_data']['heading'] ) :
														print_module('heading',[
															$block_content['login_data']['heading']
														]);
													endif; 
												endif;						
												// Content.
												if ( $block_content['login_data']['content'] ) :
													print_element( 'content', [
														'content' => $block_content['login_data']['content'],
														'class'   => [ 'card-text', 'post-excerpt', 'm-0' ],
													] );
												endif; ?>
											</div><?php
											// Button
											if ( !empty($block_content['login_data']['buttons']) ) : ?>
												<div class="buttons"><?php
													foreach($block_content['login_data']['buttons'] as $button){ ?>
														<div class="button-item"><?php
															if ( $button['heading'] ) :
																print_element( 'heading', [
																	'text'  => $button['heading'],
																	'level' => 5,
																	'class' => [ 'pricing-title', 'h5' ],
																] );
															endif; 
															// Button
															if ( !empty($button['button']) ) :
																$button = $button['button'];
																$button['class'] = [ ''];
																print_element( 'button', $button );
															endif; ?>
														</div><?php
													} ?>
												</div><?php 
											endif;?>
										</div><?php
										if ( ! empty( $block_content['login_data']['info_modal']['modal_link_title'] ) ) : ?>
											<div class="card-links">
												<a href="javascript:;" class="common-popup" id="<?php echo 'login_data'.$block['id']; ?>"><?php echo $block_content['login_data']['info_modal']['modal_link_title']; ?></a>
											</div><?php
										endif; 
									echo '</div></div>';?>
						</div><?php
					endif;
					if ( ! empty( $block_content['dispute_data'] ) ) : ?>
						<div class="<?php echo esc_attr( $row_class ); ?> gap-24 justify-content-center"><?php
								echo '<div class="pt-120"> <div class="pricing-card-box">'; ?>
										<div class="pricing-card-body">
											<div class="pricing-card-text"><?php
												// Heading.
												if ( $block_content['dispute_data']['heading'] ) :
													if ( $block_content['dispute_data']['heading'] ) :
														print_module('heading',[
															$block_content['dispute_data']['heading']
														]);
													endif; 
												endif;						
												// Content.
												if ( $block_content['dispute_data']['content'] ) :
													print_element( 'content', [
														'content' => $block_content['dispute_data']['content'],
														'class'   => [ 'card-text', 'post-excerpt', 'm-0' ],
													] );
												endif; ?>
											</div><?php
											// Button
											if ( !empty($block_content['dispute_data']['buttons']) ) : ?>
												<div class="buttons"><?php
													foreach($block_content['dispute_data']['buttons'] as $button){ ?>
														<div class="button-item"><?php
															if ( $button['heading'] ) :
																print_element( 'heading', [
																	'text'  => $button['heading'],
																	'level' => 5,
																	'class' => [ 'pricing-title', 'h5' ],
																] );
															endif; 
															// Button
															if ( !empty($button['button']) ) :
																$button = $button['button'];
																$button['class'] = [ ''];
																print_element( 'button', $button );
															endif; ?>
														</div><?php
													} ?>
												</div><?php 
											endif;?>
										</div><?php
										if ( ! empty( $block_content['dispute_data']['info_modal']['modal_link_title'] ) ) : ?>
											<div class="card-links">
												<a href="javascript:;" class="common-popup" id="<?php echo 'dispute_data'.$block['id']; ?>"><?php echo $block_content['dispute_data']['info_modal']['modal_link_title']; ?></a>
											</div><?php
										endif; 
									echo '</div></div>';?>
						</div><?php
					endif;  ?>
				</div>
			</div>
		</div><?php
		if ( ! empty( $block_content['login_data']['info_modal'] ) ) :
			$block_content['login_data']['info_modal']["id"] = 'login_data'.$block['id'];
			print_module(
				'modal-info',
				$block_content['login_data']['info_modal']
			);
		endif; 
		if ( ! empty( $block_content['dispute_data']['info_modal'] ) ) :
			$block_content['dispute_data']['info_modal']["id"] = 'dispute_data'.$block['id'];
			print_module(
				'modal-info',
				$block_content['dispute_data']['info_modal']
			);
		endif; ?>
	</section>
<?php endif; ?>