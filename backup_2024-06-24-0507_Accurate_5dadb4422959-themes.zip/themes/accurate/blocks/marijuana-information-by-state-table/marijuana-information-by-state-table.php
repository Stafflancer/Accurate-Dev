<?php
/**
 * BLOCK: Marijuana Information by State Table
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'marijuana-information-by-state-table-' . $block['id'],
	'class'    => [ 'acf-block', 'marijuana-information-by-state-table', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'table_heading',
	'table_content',
	'table',
	'footnote',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );

$row_class    = join( ' ', [
	'row',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

if ( ! empty( $block_content['table_heading'] ) || ! empty( $block_content['table_content'] ) || ! empty( $block_content['table'] ) || ! empty( $block_content['footnote'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> <?php echo esc_attr( $column_class ); ?>">
			<?php if ( ! empty( $block_content['table_heading'] ) || ! empty( $block_content['table_content'] ) ) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="col-12">
						<div class="section-header-outer">
							<?php
							// Heading.
							if ( $block_content['table_heading'] ) :
								print_element( 'heading', [
									'text'  => $block_content['table_heading'],
									'level' => 2,
									'class' => [ 'table-title' ],
								] );
							endif;

							// Content.
							if ( ! empty( $block_content['table_content'] ) ) :
								print_element( 'content', [
									'content' => $block_content['table_content'],
								] );
							endif;
							?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $block_content['table'] ) ) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?> gap-64">
					<div class="col-12">
						<div class="marijuana-information-by-state-table-main">
							<table>
								<thead>
								<tr>
									<th class="text-uppercase">State</th>
									<th class="text-uppercase">Legal Status</th>
									<th class="text-uppercase">Medicinal</th>
									<th class="text-uppercase">Recreational</th>
									<th class="text-uppercase">State Laws</th>
								</tr>
								</thead>
								<tbody>
								<?php
								$animation_delay = 0;
								foreach ( $block_content['table'] as $cards ):
									if ( $cards['is_state'] == 'state' ) {
										$class = 'text-pink';
									} else {
										$class = 'text-pale-blue';
									}
									echo '<tr class="' . $class . '">';
									echo '<td>';
									if ( $cards['is_state'] == 'state' ) {
										print_element( 'anchor', [
											'text'   => $cards['state__jurisdiction']['title'] . ' ',
											'href'   => $cards['state__jurisdiction']['url'],
											'target' => $cards['state__jurisdiction']['target'],
										] );
									} else {
										print_element( 'anchor', [
											'text'   => $cards['state__jurisdiction']['title'] . ' ',
											'href'   => $cards['state__jurisdiction']['url'],
											'target' => $cards['state__jurisdiction']['target'],
										] );
									}
									echo '</td>';

									// Heading.
									echo '<td>';
									print_element( 'content', [
										'content' => $cards['legal'],
									] );
									echo '</td>';

									// Content.
									echo '<td>';
									print_element( 'content', [
										'content' => $cards['protections_for_medicinal_users_&_exceptions'],
									] );
									echo '</td>';

									echo '<td>';
									print_element( 'content', [
										'content' => $cards['protections_for_recreational_users_&_exceptions'],
									] );
									echo '</td>';

									echo '<td>';
									print_element( 'content', [
										'content' => $cards['restrictions_on_the_ability_to_test_for_cannabis'],
									] );
									echo '</td>';
									echo '</tr>';
									$animation_delay += 0.25;
								endforeach;
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php
			// Content.
			if ( ! empty( $block_content['footnote'] ) ) :
				echo '<div class="footnote">';
				print_element( 'content', [
					'content' => $block_content['footnote'],
					'class'   => 'footnote-content',
				] );
				echo '</div>';
			endif;
			?>
		</div>
	</section>
<?php endif; ?>