jQuery(document).ready(function ($) {
	let a = false;
	$(window).scroll(function () {
		let oTop = $('.circles-stats-row').offset().top - window.innerHeight;
		if (!a && $(window).scrollTop() > oTop) {
			var i = 1;
			jQuery('.stats-item').each(function (index) {
				let num = jQuery(this).find('.circle-stat-val').data('value');

				const od = new Odometer({
					el: document.getElementById('odometer' + i),
					format: '(,ddd).dd',
					duration: 3000,
					theme: 'default'
				});
				od.render();

				// Initiate animation.
				setTimeout(function () {
					od.update(num);
				}, 100);
				i++;
			});
			a = true;
		}
	});
});