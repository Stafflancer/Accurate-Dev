<?php
/**
 * BLOCK: Stats in Circles
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'stats-in-circles-' . $block['id'],
	'class'    => [ 'acf-block', 'stats-in-circles', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'number_of_columns',
	'stats',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'inner-container-width cols-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );

$row_class    = join( ' ', [
	'row',
] );
$column_class = join( ' ', [
	$column_size_class,
] );
$classes      = '';

if ( $block_content['number_of_columns'] == 2 ) {
	$classes = "item-2";
} elseif ( $block_content['number_of_columns'] == 3 ) {
	$classes = "item-3";
} elseif ( $block_content['number_of_columns'] == 4 ) {
	$classes = "item-4";
} else {
	$classes = "item-5";
}
if ( ! empty( $block_content['heading'] ) || ! empty( $block_content['content'] ) || ! empty( $block_content['stats'] ) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> z-9">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="stats-outer">
						<?php if ( array_key_exists( "main_heading", $block_content['heading'] ) && ! empty( $block_content['heading']['main_heading'] ) || ! empty( $block_content['content'] ) ) : ?>
							<div class="stats-main-text">
								<?php
								// Heading
								if ( $block_content['heading'] ) :
									print_module( 'heading', [
										$block_content['heading'],
									] );
								endif;
								if ( $block_content['content'] ) :
									print_element( 'content', [
										'content' => $block_content['content'],
										'class'   => [ 'text', 'post-excerpt', 'm-0' ],
									] );
								endif;
								?>
							</div>
						<?php endif; ?>
						<div class="stats">
							<div class="stats-row circles-stats-row <?php echo $classes; ?>">
								<?php
								$counter                  = 1;
								if ( $block_content['stats'] ) :
									foreach ( $block_content['stats'] as $stats ) :
										$prefix = $stats['prefix'];
										$stat             = $stats['stat'];
										$suffix           = $stats['suffix'];
										$content          = $stats['content'];
										$divider_image    = $stats['divider_image'];
										$divider_position = $stats['divider_position'];
										?>
										<div class="stats-item">
											<div class="prefix">
												<div class="stats-inner">
													<h3 class="acf-element-heading">
														<span><?php echo esc_html( $prefix ); ?></span><span class="stat-outer"><span id="odometer<?php echo $counter; ?>" class="circle-stat-val" data-value="<?php echo esc_html( $stat ); ?>"><?php echo esc_html( $stat ); ?> </span><?php echo esc_html( $suffix ); ?></span>
													</h3>
													<?php
													if ( ! empty( $content ) ) :
														print_element( 'content', [
															'content' => $content,
														] );
													endif;
													?>
													<?php
													if ( ! empty( $divider_image ) ) {
														$image_class = "divider-img";
														?>
														<div class="divider-image <?php echo "divider-position-" . $divider_position; ?>">
															<?php echo wp_get_attachment_image( $divider_image, 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
														</div>
													<?php } ?>
												</div>
											</div>
										</div>
										<?php
										$counter++;
									endforeach;
								endif;
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>