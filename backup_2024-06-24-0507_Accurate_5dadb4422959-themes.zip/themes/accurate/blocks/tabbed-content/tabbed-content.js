jQuery(document).ready(function($) {
  var swiper = new Swiper(".tabs-content-slider", {
      loop: false,
      slidesPerView: 1,
      spaceBetween: 25,
      watchSlidesProgress: true,
      breakpoints: {
          1024: {
              slidesPerView: 1,
          },
          768: {
              slidesPerView: 1,
          },
          480: {
              slidesPerView: 1,
          },
          320: {
              slidesPerView: 1,
          }
      },
      navigation: {
          nextEl: '.next',
          prevEl: '.prev',
      },
      on: {
          slideChange: function() {
              var activeSlideIndex = swiper.activeIndex;
              $('ul.tabs li').removeClass('current');
              $('ul.tabs li[data-tab="' + (activeSlideIndex + 1) + '"]').addClass('current');
          }
      },
  });

  $('ul.tabs li').click(function() {
      var tab_id = $(this).attr('data-tab');
      swiper.slideTo(tab_id - 1); // Swiper uses zero-based index
  });
});
