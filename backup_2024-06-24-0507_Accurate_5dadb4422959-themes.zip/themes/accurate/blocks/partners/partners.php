<?php
/**
 * BLOCK: Partners
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\get_trimmed_excerpt;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'partners-' . $block['id'],
	'class'    => [ 'acf-block', 'search-filter', 'partners', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'tagline',
	'heading',
	'content',
	'partner_type',
	'partners_result_shortcode',
	'partners_result_shortcode_filter',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'col-12 col-md-'.$design_options['column_size'];
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	$column_size_class,
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	'partners-inner',
] ); 

if ( !empty($block_content['tagline']) || !empty($block_content['heading']) || !empty($block_content['content']) || !empty($block_content['partner_type'])) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>"><?php
				//	Heading
					if ( $block_content['tagline'] ) :
						print_element('tagline',[
							'text' => $block_content['tagline']
						]);
					endif;
					//	Heading
					if ( $block_content['heading'] ) :
						print_module('heading',[
							$block_content['heading']
						]);
					endif;
					// Content.
					if ( $block_content['content'] ) :
						print_element( 'content', [
							'content' => $block_content['content'],
						] );
					endif; 
					$post  = array(
						'numberposts' => -1,
						'post_type'   => 'partner',
						'orderby'     => 'date',
						'order'       => 'DESC',
						'meta_query' => array(
					        array(
					            'key'       => 'featured_partner',
					            'value'     => '1',
					            'compare'   => '=',
					        ),
					    ),
						'tax_query' => array(
					        array(
					            'taxonomy' => 'partner_type',
					            'field'    => 'term_id',
					            'terms'    => $block_content['partner_type']
					        )
					    )
					);
					$latest_post = get_posts( $post );
					if ( !empty( $latest_post ) ) :
						global $post; ?>
						<div class="partners"><?php
							foreach ( $latest_post as $post ) :
								setup_postdata( $post ); 
								$image = get_post_thumbnail_id(); 
								$excerpt = get_trimmed_excerpt( [ 'post' => get_the_ID() ] );
								$featured_partner = get_field('featured_partner', get_the_ID());
								$image_class = ""; ?>
								<div class="partner-item">
									<figure class="partners-img round-partner-image"><?php 
										if ( ! empty( $image ) ) : ?>
											<?php echo wp_get_attachment_image( $image, 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
										<?php else: ?>
											<img class="<?php echo esc_attr( $image_class ); ?>" src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>" alt="Image Placeholder" width="764" height="764" aria-hidden="true">
										<?php endif; ?>
									</figure>
									<div class="partners-content"><?php
										if($featured_partner == 1) :
											print_element( 'tagline', [
												'text'  => 'PREMIERE PARTNER',
												'class' => 'label premiere-partner-icon',
											] );
										endif;
										// Heading.
										if ( get_the_title() ) :
											print_element( 'heading', [
												'text'  => get_the_title(),
												'level' => 4,
												'class' => [ 'card-title', 'h4' ],
											] );
										endif;
										// Content.
										if ( $excerpt ) :
											print_element( 'content', [
												'content'  => $excerpt,
												'class' => [ 'card-content', 'h4' ],
											] );
										endif; ?>
										<div class="card-links"><?php
											print_element( 'anchor', [
												'text'  => 'Learn More >',
												'href'  =>  get_permalink(),
												'class' => 'learn-more-link',
											] ); ?>
										</div>
									</div>
								</div><?php
							endforeach;
							wp_reset_postdata(); ?>
						</div><?php
					endif;
					if(!empty($block_content['partners_result_shortcode'])){ ?>
						<div class="partners-shortcode">
							<?php echo $block_content['partners_result_shortcode_filter']; ?>
							<?php echo $block_content['partners_result_shortcode']; ?>
						</div><?php
					} ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>