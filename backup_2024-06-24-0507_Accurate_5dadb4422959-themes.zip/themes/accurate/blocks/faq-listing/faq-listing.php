<?php
/**
 * BLOCK: FAQ Listing
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'faq-listing-' . $block['id'],
	'class'    => [ 'acf-block', 'faq-listing', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [			
	'faq_filter',
	'faq_results',
	'info_modal',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );
if ( !empty($block_content['faq_filter']) || !empty($block_content['faq_results']) || !empty($block_content['info_modal']) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="faq-filter-buttons"><?php
		                if(!empty($block_content['faq_filter'])){ ?>
		                    <div class="shortcode-filter-1">
		                        <div class="shortcode-filter-inner-1">
		                            <?php echo $block_content['faq_filter']; ?>
		                        </div>
		                    </div><?php
		                } 
		                if ( ! empty( $block_content['info_modal']['modal_link_title'] ) ) : ?>
							<div class="modal-popup-link">
								<a href="javascript:;" class="faq-listing-link common-popup" id="<?php echo $block['id']; ?>"><?php echo $block_content['info_modal']['modal_link_title']; ?></a>
							</div><?php
						endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="shortcode-result-outer bg-white" style="display: none;">
			<div class="<?php echo esc_attr( $container_class ); ?>">
				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="col-md-12 col-sm-12"><?php
		                if(!empty($block_content['faq_results'])){ ?>
		                    <div class="shortcode-result-1">
		                        <?php echo $block_content['faq_results']; ?>
		                    </div><?php
		                } ?>
					</div>
				</div>
			</div>
		</div><?php
		if ( ! empty( $block_content['info_modal'] ) ) :
			$block_content['info_modal']["id"] = $block['id'];
			print_module(
				'modal-info',
				$block_content['info_modal']
			);
		endif; ?>
	</section>
<?php endif; ?>