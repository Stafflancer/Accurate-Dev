jQuery(document).ready(function ($) {
	function getQueryParam(name) {
		name = name.replace(/[\[\]]/g, '\\$&');
		var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
			results = regex.exec(window.location.href);
		if (!results) return null;
		if (!results[2]) return '';
		return decodeURIComponent(results[2].replace(/\+/g, ' '));
	}

	function showShortcodeResult() {
		$('.shortcode-result-outer').show();
	}

	var faqType = getQueryParam('_sft_faq_type');
	if (faqType) {
		showShortcodeResult();
	}

	$(document).ajaxSuccess(function () {
		var faqTypeAfterAjax = getQueryParam('_sft_faq_type');
		if (faqTypeAfterAjax) {
			showShortcodeResult();
		}
	});

	$('.faqs-panel-heading').first().addClass('open');
	$('.faqs-panel-content').first().show();
	$('.faqs-panel-heading').click(function (e) {
		var $panelHeading = $(this),
			$panelContent = $panelHeading.next('.faqs-panel-content');

		if ($panelHeading.hasClass('open')) {
			$panelHeading.removeClass('open');
			$panelContent.slideUp();
		} else {
			$('.faqs-panel-heading').removeClass('open');
			$('.faqs-panel-content').slideUp();
			$panelHeading.addClass('open');
			$panelContent.slideDown();
		}
	});

	$(document).on('sf:ajaxfinish', '.searchandfilter', function () {
		$('.faqs-panel-heading').click(function (e) {
			var $panelHeading = $(this),
				$panelContent = $panelHeading.next('.faqs-panel-content');

			if ($panelHeading.hasClass('open')) {
				$panelHeading.removeClass('open');
				$panelContent.slideUp();
			} else {
				$('.faqs-panel-heading').removeClass('open');
				$('.faqs-panel-content').slideUp();
				$panelHeading.addClass('open');
				$panelContent.slideDown();
			}
		});
	});
});