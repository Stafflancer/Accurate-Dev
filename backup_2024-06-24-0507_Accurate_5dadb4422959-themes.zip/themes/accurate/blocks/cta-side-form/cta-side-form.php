<?php
/**
 * BLOCK: CTA - Side Form
 *
 * @param array        $block      The block settings and attributes.
 * @param string       $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'cta-side-form-' . $block['id'],
	'class'    => [ 'acf-block', 'cta', 'cta-side-form', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'form',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'col-12 col-md-'.$design_options['column_size'].' col-sm-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] ); 

if ( !empty($block_content['heading'] ) || !empty($block_content['content'] ) || !empty( $block_content['form'] ) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> <?php echo esc_attr( $column_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>  align-items-center justify-content-between"><?php
				if ( array_key_exists("main_heading",$block_content['heading']) && !empty($block_content['heading']['main_heading']) || !empty($block_content['content'])) : ?>			
					<div class="col-lg-5 col-md-6 col-sm-12">
						<?php
						//	Heading
						if ( !empty($block_content['heading']) ) :
							print_module('heading',[
								$block_content['heading']
							]);
						endif;
						// Content.
						if ( !empty($block_content['content']) ) :
							print_element( 'content', [
								'content' => $block_content['content'],
							] );
						endif;
						?>
					</div><?php
				endif; 
				// Form.
				if ( $block_content['form'] ) : ?>
					<div class="col-lg-6 col-md-6 col-sm-12" data-wow-delay="0.25s">
						<div class="cta-form-main"><?php
						
							// If out form is an embed code, echo the content.
							// echo wp_kses_post( $block_content['form'] );
							// If our form is gravity form echo the shortcode.
							echo do_shortcode( '[gravityform id="' . $block_content['form'] . '" title="false" description="false" ajax="true"]' ); ?>
						</div>
					</div><?php
				endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>