var swiper = new Swiper(".slider-timeline-cards", {
    loop: false,
    slidesPerView: 3,
    spaceBetween: 24,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 3,
      },
      768: {
        slidesPerView: 2,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    navigation: {
      nextEl: '.next',
      prevEl: '.prev',
    },
});