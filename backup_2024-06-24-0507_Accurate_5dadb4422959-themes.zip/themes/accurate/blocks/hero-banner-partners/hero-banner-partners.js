var swiper = new Swiper(".slider-hero-partners", {
    loop: false,
    slidesPerView: 1,
    spaceBetween: 25,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 1,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    navigation: {
      nextEl: '.next',
      prevEl: '.prev',
    },
});