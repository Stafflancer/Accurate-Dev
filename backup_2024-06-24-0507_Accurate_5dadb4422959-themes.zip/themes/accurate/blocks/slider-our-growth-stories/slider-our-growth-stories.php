<?php
/**
 * BLOCK: Slider - Our Growth Stories
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_trimmed_excerpt;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'slider-our-growth-stories-' . $block['id'],
	'class'    => [ 'acf-block', 'slider-our-growth-stories', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'description',
	'display',
	'people',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'col-12 col-md-'.$design_options['column_size'];
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] ); 

if ( !empty($block_content['heading']) || !empty($block_content['description']) || !empty($block_content['display']) || !empty($block_content['people']) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>"><?php
			if ( array_key_exists("main_heading",$block_content['heading']) && !empty($block_content['heading']['main_heading']) || !empty($block_content['description'])) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?> justify-content-center">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-outer"><?php
							//	Heading
							if ( $block_content['heading'] ) :
								print_module('heading',[
									$block_content['heading']
								]);
							endif;
							// Content.
							if ( $block_content['description'] ) :
								print_element( 'content', [
									'content' => $block_content['description'],
								] );
							endif; ?>
						</div>
					</div>
				</div><?php
			endif; ?>	
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="section-header-after-sec"><?php
						if ( ! empty( $block_content['people'] ) ) : 
							global $post; ?>
							<div class="swiper slider-people">
								<div class="swiper-wrapper"><?php
									foreach ( $block_content['people'] as $post ):
										setup_postdata( $post );
										$title = get_field('title', get_the_ID()); 
										$image = get_post_thumbnail_id(); 
										$image_class = ''; ?>
										<div class="swiper-slide">
											<div class="slider-our-growth-stories-main">
												<figure class="slider-our-growth-stories-img">
													<?php if ( ! empty( $image ) ) : ?>
														<?php echo wp_get_attachment_image( $image, 'medium', array( 'class' => esc_attr( $image_class ) ) ); ?>
													<?php else: ?>
														<img class="<?php echo esc_attr( $image_class ); ?>"
														     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
														     alt="Image Placeholder" width="764" height="764" aria-hidden="true">
													<?php endif; ?>
												</figure>
												<div class="slider-people-text"><?php
													// Heading.
													if ( get_the_title() ) :
														print_element( 'heading', [
															'text'  => get_the_title(),
															'level' => 3,
															'class' => [ 'card-title', 'h34', 'text-capitalize' ],
														] );
													endif;
													// Title
													if (!empty($title)) :
														print_element( 'tagline', [
															'text'  => $title,
															'class' => 'company-name',
														]);	
													endif; 
													// Content.
													if ( get_trimmed_excerpt( [ 'post' => get_the_ID() ] ) ) :
														print_element( 'content', [
															'content' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
															'class'   => [ 'post-excerpt', 'm-0' ],
														] );
													endif; ?>
													<div class="is-style-fill"><?php
														// Link.
														if ( get_permalink() ) :
															print_element('anchor',[
																'text' => 'Read',
																'href' => get_permalink(),
																'class' => 'acf-element-button has-background has-pink-background-color has-color-white growth-stories-btn',
															]);
														endif; ?>
													</div>
												</div>
											</div>
										</div><?php
									endforeach; ?>
								</div>
								<div class="swiper-pagination"></div>
							</div><?php
						endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>