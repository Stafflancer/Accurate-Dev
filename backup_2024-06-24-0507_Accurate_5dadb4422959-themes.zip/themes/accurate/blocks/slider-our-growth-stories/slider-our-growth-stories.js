var swiper = new Swiper(".slider-people", {
    loop: true,
    slidesPerView: 1,
    spaceBetween: 0,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 1,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
});