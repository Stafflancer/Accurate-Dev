jQuery(document).ready(function ($) {
	// Hide all inner tab content panels.
	$('.tab-content-panel .tab-panel').hide();
	$('.inner-tab-content').hide();

	// Add click event for parent tabs
	$('.tab-header-item-click').click(function () {
		// Remove the "active" class from all parent tabs.
		$('.tab-header-item-click').removeClass('active');
		// Add the "active" class to the clicked parent tab.
		$(this).addClass('active');
		$('.tab-content-panel .tab-panel').removeClass('active').hide();

		var tabName = $(this).data('tab');

		// Add the "active" class to the tab panel corresponding to the clicked parent tab.
		$('.tab-panel[data-tab="' + tabName + '"]').addClass('active');
		$('.tab-content-panel .tab-panel.active').show();

		// Hide all inner tab content panels within the active content panel.
		$('.tab-panel .inner-tab-content').hide();

		var href = $(this).attr('href');
		$('html,body').animate({
			scrollTop: $(href).offset().top - 180
		}, 800);
	});

	// Add click event for inner tab names
	$('.inner-tab-item-click').click(function () {
		// Hide all inner tab content panels within the active content panel.
		var innerTabName = $(this).data('inner-tab-name');
		$('.inner-tab-item-click').removeClass('active');
		$('.inner-tab_content_container .inner-tab-content').removeClass('active').hide();

		// Show the content of the clicked inner tab.
		$(this).addClass('active');
		var innerTabContent = $('.inner-tab_content_container .inner-tab-content[data-inner-tab="' + innerTabName + '"]');
		innerTabContent.addClass('active').show();
		// var tabindex = $(this).attr('href');
		var closestGFormWrapper = innerTabContent.find('.acf-element-content').closest('.acf-element-content');
		$('html,body').animate({
			scrollTop: $(closestGFormWrapper).offset().top - 180
		}, 800);
	});

	var hash = window.location.hash.substring(1),
		myBackgrounds = ['background-accel-phone', 'background-ace-phone', 'background-now-phone'];

	if (myBackgrounds.includes(hash)) {
		let $innerTabButton = jQuery('.' + hash);

		jQuery('.candidate-tab').click();

		if ( $innerTabButton.length ) {
			$innerTabButton.click();
			jQuery('html, body').animate({
				scrollTop: jQuery('#' + hash).offset().top - 300
			}, 1000);
		}
		// if ('background-accel-phone' === hash) {
		// 	jQuery('.background-accel-phone').click();
		// 	jQuery('html, body').animate({
		// 		scrollTop: jQuery('#' + hash).offset().top - 300
		// 	}, 1000);
		// } else if ('background-ace-phone' === hash ) {
		// 	jQuery('.candidate-tab').click();
		// 	jQuery('.background-ace-phone').click();
		// 	jQuery('html, body').animate({
		// 		scrollTop: jQuery('#background-ace-phone').offset().top - 300
		// 	}, 1000);
		// } else if () {
		// 	jQuery('.custom-tab').find('a[href*="#my-background-check-tab"]').click();
		// 	jQuery('a[href*="#' + hash + '"]').click();
		// }
	}
});