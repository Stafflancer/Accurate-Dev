<?php
/**
 * BLOCK: Contact Info
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'contact-info-' . $block['id'],
	'class'    => [ 'acf-block', 'contact-info-sec', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'inner_section_heading',
	'inner_tab_heading',
	'description',
	'first_tab_name',
	'current_client_tab_content',
	'current_client_inner_tabbing',
	'second_tab_name',
	'prospective_client_tab_content',
	'prospective_client_inner_tabbing',
	'prospective_content',
	'third_tab_name',
	'candidate_tab_content',
	'candidate_inner_tabbing',
	'modal_info',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'inner-container-width cols-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class       = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );
if ( ! empty( $block_content['heading'] ) || ! empty( $block_content['inner_section_heading'] ) || ! empty( $block_content['inner_tab_heading'] ) || ! empty( $block_content['description'] ) || ! empty( $block_content['first_tab_name'] ) || ! empty( $block_content['current_client_tab_content'] ) || ! empty( $block_content['current_client_inner_tabbing'] ) || ! empty( $block_content['second_tab_name'] ) || ! empty( $block_content['prospective_client_tab_content'] ) || ! empty( $block_content['prospective_client_inner_tabbing'] ) || ! empty( $block_content['third_tab_name'] ) || ! empty( $block_content['candidate_tab_content'] ) || ! empty( $block_content['prospective_content'] ) || ! empty( $block_content['candidate_inner_tabbing'] ) || ! empty( $block_content['modal_info'] ) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="breadcrumb">
						<ul class="breadcrumb-inner">
							<?php bcn_display(); ?>
						</ul>
					</div>
					<?php
					if ( array_key_exists( "main_heading", $block_content['heading'] ) && ! empty( $block_content['heading']['main_heading'] ) || ! empty( $block_content['description'] ) ) { ?>
						<div class="section-heading"><?php
						if ( ! empty( $block_content['heading'] ) ) {
							//	Heading
							if ( $block_content['heading'] ) :
								print_module( 'heading', [
									$block_content['heading'],
								] );
							endif;
						}
						if ( ! empty( $block_content['description'] ) ) {
							// Content.
							if ( $block_content['description'] ) :
								print_element( 'content', [
									'content' => $block_content['description'],
									'class'   => [ 'body-size-large' ],
								] );
							endif;
						} ?>
						</div>
					<?php } ?>
					<div class="tab-container">
						<?php
						// Heading.
						if ( $block_content['inner_section_heading'] ) :
							print_element( 'heading', [
								'text'  => $block_content['inner_section_heading'],
								'level' => 2,
								'class' => [ 'card-title', 'h4' ],
							] );
						endif;
						?>
						<ul class="tab-header tab-list-box">
							<!-- First Tab -->
							<?php if ( $block_content['first_tab_name'] ) : ?>
								<li class="tab-header-item tab-item-list">
									<div class="is-style-outline">
										<a href="#current-client" data-tab="current-client" class="acf-element tab-header-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo esc_html( $block_content['first_tab_name'] ); ?></a>
									</div>
									<p>
										<?php
										if ( $block_content['current_client_tab_content'] ) :
											print_element( 'content', [
												'content' => $block_content['current_client_tab_content'],
												'class'   => 'text-center',
											] );
										endif;
										?>
									</p>
								</li>
							<?php endif; ?>

							<!-- Second Tab -->
							<?php if ( $block_content['second_tab_name'] ) : ?>
								<li class="tab-header-item tab-item-list">
									<div class="is-style-outline">
										<a href="#prospective-client" data-tab="prospective-client" class="acf-element tab-header-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo esc_html( $block_content['second_tab_name'] ); ?></a>
									</div>
									<p>
										<?php
										if ( $block_content['prospective_client_tab_content'] ) :
											print_element( 'content', [
												'content' => $block_content['prospective_client_tab_content'],
												'class'   => 'text-center',
											] );
										endif;
										?>
									</p>
								</li>
							<?php endif; ?>

							<!-- Third Tab -->
							<?php if ( $block_content['third_tab_name'] ) : ?>
								<li class="tab-header-item tab-item-list">
									<div class="is-style-outline">
										<a href="#candidate" data-tab="candidate" class="candidate-tab acf-element tab-header-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo esc_html( $block_content['third_tab_name'] ); ?></a>
									</div>
									<p>
										<?php
										if ( $block_content['candidate_tab_content'] ) :
											print_element( 'content', [
												'content' => $block_content['candidate_tab_content'],
												'class'   => 'text-center',
											] );
										endif;
										?>
									</p>
								</li>
							<?php endif; ?>
						</ul>
						<div class="tab-content-panel">
							<!-- First Tab Content -->
							<div id="current-client" class="tab-panel tab-panel-all-data" data-tab="current-client">
								<?php
								// Heading.
								if ( $block_content['inner_tab_heading'] ) :
									print_element( 'heading', [
										'text'  => $block_content['inner_tab_heading'],
										'level' => 2,
										'class' => [ 'card-title', 'h2' ],
									] );
								endif;
								?>
								<?php if ( have_rows( 'current_client_inner_tabbing' ) ) : ?>
									<div class="inner-tab-panel">
										<ul class="tab-list-box">
											<?php
											$innerTabIndex = 0; // Initialize a variable to keep track of the inner tab index.
											$tabSlugs      = [];
											foreach ( $block_content['current_client_inner_tabbing'] as $current_client_tab ):
												$innerTabName = $current_client_tab['inner_tab_name'];
												$innerTabSlug = 'current-client-' . sanitize_title( $innerTabName );
												$tabSlugs[ $innerTabIndex ] = $innerTabSlug;

												if ( ! empty( $innerTabName ) ) : ?>
													<li class="tab-item-list">
														<div class="is-style-outline">
															<a href="#<?php echo $innerTabSlug; ?>" data-inner-tab-name="<?php echo $innerTabSlug; ?>" class="acf-element inner-tab-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo $innerTabName; ?></a>
														</div>
													</li>
												<?php
												endif;
												$innerTabIndex++; // Increment the inner tab index for uniqueness
											endforeach;
											?>
										</ul>
										<div class="inner-tab_content_container">
											<?php
											$innerTabContentIndex = 0;
											foreach ( $block_content['current_client_inner_tabbing'] as $current_client_tab ):
												$current_client_tab_inner_content = $current_client_tab['inner_tab_conent'];
												?>
													<div class="inner-tab-content" data-inner-tab="<?php echo $tabSlugs[ $innerTabContentIndex ]; ?>">
														<?php
														if ( ! empty( $current_client_tab_inner_content ) ) :
															print_element( 'content', [
																'content' => $current_client_tab_inner_content,
															] );
														endif;

														if ( $current_client_tab['inner_button'] ) :
															$buttons['class'] = [ 'contact-buttons' ];
															print_module( 'buttons-group', $current_client_tab['inner_button'] );
														endif;

														if ( $current_client_tab['form_content'] ) :
															echo $current_client_tab['form_content'];
														endif;

														if ( $current_client_tab['inner_tab_form'] ) :
															echo do_shortcode( '[gravityform id="' . $current_client_tab['inner_tab_form'] . '" title="false" description="false" ajax="true"]' );
														endif;

														$accel_footer_phone_number  = $current_client_tab['phone_number'];
														$accel_footer_phone2_number = $current_client_tab['phone_2_number'];

														if ( ! empty( $current_client_tab['phone_title'] ) || ! empty( $accel_footer_phone_number ) || ! empty( $accel_footer_phone2_number ) || ! empty( $current_client_tab['international_number'] ) || ! empty( $current_client_tab['main_heading'] ) || ! empty( $current_client_tab['main_description'] ) ) {
															if ( ! empty( $current_client_tab['phone_title'] ) || ! empty( $accel_footer_phone_number ) || ! empty( $accel_footer_phone2_number ) || ! empty( $current_client_tab['international_number'] ) ) {
																$single_content_class = 'not-full';
															} else {
																$single_content_class = 'full';
															}
															?>
															<section class="bg-primary-bright-blue section-padding text-white current-client-bottom">
																<div class="container">
																	<div class="row <?php echo $single_content_class; ?>">
																		<?php if ( ! empty( $current_client_tab['main_heading'] ) || ! empty( $current_client_tab['main_description'] ) ) { ?>
																			<div class="col-md-5">
																				<div class="section-heading">
																					<?php if ( ! empty( $current_client_tab['main_heading'] ) ) { ?>
																						<h2 class="text-primary-orange"><?php echo $current_client_tab['main_heading']; ?></h2>
																					<?php } ?>
																					<?php if ( ! empty( $current_client_tab['main_description'] ) ) { ?>
																						<p class="desc large"><?php echo $current_client_tab['main_description']; ?></p>
																					<?php } ?>
																				</div>
																			</div>
																		<?php } ?>
																		<?php if ( ! empty( $current_client_tab['phone_title'] ) || ! empty( $accel_footer_phone_number ) || ! empty( $accel_footer_phone2_number ) || ! empty( $current_client_tab['international_number'] ) ) { ?>
																			<div class="col-md-6 offset-md-1">
																				<div class="section-heading">
																					<?php if ( ! empty( $current_client_tab['phone_title'] ) ) { ?>
																						<p class="desc large text-primary-orange mb-1 font-weight-500"><?php echo $current_client_tab['phone_title']; ?></p>
																					<?php } ?>
																					<?php if ( ! empty( $accel_footer_phone_number ) || ! empty( $accel_footer_phone2_number ) ) { ?>
																						<div class="phone_numbers">
																							<?php
																							if ( ! empty( $accel_footer_phone_number ) ) { ?>
																								<p class="desc"><?php echo $current_client_tab['phone_number_prefix_label']; ?>
																									&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $accel_footer_phone_number ); ?>"><?php echo $accel_footer_phone_number; ?></a>
																								</p>
																							<?php } ?>
																							<?php if ( ! empty( $accel_footer_phone2_number ) ) { ?>
																								<p class="desc"><?php echo $current_client_tab['phone_2_number_prefix_label']; ?>
																									&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $accel_footer_phone2_number ); ?>"><?php echo $accel_footer_phone2_number; ?></a>
																								</p>
																							<?php } ?>
																						</div>
																					<?php } ?>
																					<?php if ( ! empty( $current_client_tab['international_number'] ) ) { ?>
																						<div class="row">
																							<div class="col-lg-8">
																								<select class="custom-select custom-select-lg mb-3">
																									<option value="">INTERNATIONAL NUMBERS</option>
																									<?php foreach ( $current_client_tab['international_number'] as $numbers ) { ?>
																										<option value="<?php echo $numbers['number']; ?>"><?php echo $numbers['country_name']; ?></option>
																									<?php } ?>
																								</select>
																							</div>
																						</div>
																						<p class="desc">
																							<a href="" class="international-tel-number tel-link"></a>
																						</p>
																					<?php } ?>
																				</div>
																			</div>
																		<?php } ?>
																	</div>
																</div>
															</section>
														<?php } ?>
													</div>
												<?php
												$innerTabContentIndex++;
											endforeach;
											?>
										</div>
									</div>
								<?php endif; ?>
							</div>

							<!-- Second Tab Content -->
							<div class="tab-panel tab-panel-all-data" data-tab="prospective-client" id="prospective-client">
								<?php if ( $block_content['prospective_content'] ) : ?>
									<div class="contact-para">
										<?php echo $block_content['prospective_content']; ?>
									</div>
								<?php endif; ?>
								<?php if ( have_rows( 'prospective_client_inner_tabbing' ) ) : ?>
									<div class="inner-tab-panel">
										<ul class="tab-list-box prospective-client">
											<?php
											$innerTabIndex = 0; // Initialize a variable to keep track of the inner tab index
											$tabSlugs      = [];
											foreach ( $block_content['prospective_client_inner_tabbing'] as $prospective_client_tab ):
												$innerTabName = $prospective_client_tab[ 'inner_tab_name' ];
												$innerTabSlug = 'prospective-client-' . sanitize_title( $innerTabName );
												$tabSlugs[ $innerTabIndex ] = $innerTabSlug;

												if ( ! empty( $innerTabName ) ) :
													?>
													<li class="tab-item-list">
														<div class="is-style-outline">
															<a href="#<?php echo $innerTabSlug; ?>" data-inner-tab-name="<?php echo $innerTabSlug; ?>" class="acf-element inner-tab-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo $innerTabName; ?></a>
														</div>
													</li>
												<?php
												endif;
												$innerTabIndex++; // Increment the inner tab index for uniqueness
											endforeach;
											?>
										</ul>
										<div class="inner-tab_content_container">
											<?php
											$innerTabContentIndex = 0;
											foreach ( $block_content['prospective_client_inner_tabbing'] as $prospective_client_tab ):
												?>
												<div class="inner-tab-content" data-inner-tab="<?php echo $tabSlugs[ $innerTabContentIndex ]; ?>">
													<?php
													$prospective_client_tab_inner_content = $prospective_client_tab['inner_tab_conent'];

													if ( $prospective_client_tab_inner_content ) :
														print_element( 'content', [
															'content' => $prospective_client_tab_inner_content,
														] );
													endif;

													if ( $prospective_client_tab['inner_button'] ) :
														$buttons['class'] = [ 'contact-buttons' ];
														print_module( 'buttons-group', $prospective_client_tab['inner_button'] );
													endif;

													if ( $prospective_client_tab['form_content'] ) :
														echo $prospective_client_tab['form_content'];
													endif;

													if ( $prospective_client_tab['inner_tab_form'] ) :
														echo do_shortcode( '[gravityform id="' . $prospective_client_tab['inner_tab_form'] . '" title="false" description="false" ajax="true"]' );
													endif;

													if ( ! empty( $prospective_client_tab['phone_title_prospective'] ) || ! empty( $prospective_client_tab['phone_number_prospective'] ) || ! empty( $prospective_client_tab['phone_2_number_prospective'] ) || ! empty( $prospective_client_tab['international_number_prospective'] ) || ! empty( $prospective_client_tab['main_heading_prospective'] ) || ! empty( $prospective_client_tab['main_description_prospective'] ) ) {
														if ( ! empty( $prospective_client_tab['phone_title_prospective'] ) || ! empty( $prospective_client_tab['phone_number_prospective'] ) || ! empty( $prospective_client_tab['phone_2_number_prospective'] ) || ! empty( $prospective_client_tab['international_number_prospective'] ) ) {
															$single_content_class = 'not-full';
														} else {
															$single_content_class = 'full';
														}
														?>
														<section class="bg-primary-bright-blue section-padding text-white current-client-bottom">
															<div class="container">
																<div class="row <?php echo $single_content_class; ?>">
																	<?php if ( ! empty( $prospective_client_tab['main_heading_prospective'] ) || ! empty( $prospective_client_tab['main_description_prospective'] ) ) { ?>
																		<div class="col-md-5">
																			<div class="section-heading">
																				<?php if ( ! empty( $prospective_client_tab['main_heading_prospective'] ) ) { ?>
																					<h2 class="text-primary-orange"><?php echo $prospective_client_tab['main_heading_prospective']; ?></h2>
																				<?php } ?>
																				<?php if ( ! empty( $prospective_client_tab['main_description_prospective'] ) ) { ?>
																					<p class="desc large"><?php echo $prospective_client_tab['main_description_prospective']; ?></p>
																				<?php } ?>
																			</div>
																		</div>
																	<?php } ?>
																	<?php if ( ! empty( $prospective_client_tab['phone_title_prospective'] ) || ! empty( $prospective_client_tab['phone_number_prospective'] ) || ! empty( $prospective_client_tab['phone_2_number_prospective'] ) || ! empty( $prospective_client_tab['international_number_prospective'] ) ) { ?>
																		<div class="col-md-6 offset-md-1">
																			<div class="section-heading">
																				<?php if ( ! empty( $prospective_client_tab['phone_title_prospective'] ) ) { ?>
																					<p class="desc large text-primary-orange mb-1 font-weight-500"><?php echo $prospective_client_tab['phone_title_prospective']; ?></p>
																				<?php } ?>
																				<?php if ( ! empty( $prospective_client_tab['phone_number_prospective'] ) || ! empty( $prospective_client_tab['phone_2_number_prospective'] ) ) { ?>
																					<div class="phone_numbers">
																					<?php if ( ! empty( $prospective_client_tab['phone_number_prospective'] ) ) { ?>
																						<p class="desc"><?php echo $prospective_client_tab['phone_number_prefix_label_prospective']; ?>
																						&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $prospective_client_tab['phone_number_prospective'] ); ?>"><?php echo $prospective_client_tab['phone_number_prospective']; ?></a>
																						</p>
																					<?php } ?>
																					<?php if ( ! empty( $prospective_client_tab['phone_2_number_prospective'] ) ) { ?>
																						<p class="desc"><?php echo $prospective_client_tab['phone_2_number_prefix_label_prospective']; ?>
																						&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $prospective_client_tab['phone_2_number_prospective'] ); ?>"><?php echo $prospective_client_tab['phone_2_number_prospective']; ?></a>
																						</p>
																					<?php } ?>
																					</div>
																				<?php } ?>
																				<?php if ( ! empty( $prospective_client_tab['international_number_prospective'] ) ) { ?>
																					<div class="row">
																						<div class="col-lg-8">
																							<select class="custom-select custom-select-lg mb-3">
																								<option value="">INTERNATIONAL NUMBERS</option>
																								<?php foreach ( $prospective_client_tab['international_number_prospective'] as $numbers ) { ?>
																									<option value="<?php echo $numbers['number']; ?>"><?php echo $numbers['country_name']; ?></option>
																								<?php } ?>
																							</select>
																						</div>
																					</div>
																					<p class="desc">
																						<a href="" class="international-tel-number tel-link"></a>
																					</p>
																				<?php } ?>
																			</div>
																		</div>
																	<?php } ?>
																</div>
															</div>
														</section>
													<?php } ?>
												</div>
												<?php
												$innerTabContentIndex++;
											endforeach;
											?>
										</div>
									</div>
								<?php endif; ?>
							</div>

							<!-- Third Tab Content -->
							<div id="candidate" class="tab-panel tab-panel-all-data" data-tab="candidate">
								<?php
								// Heading.
								if ( $block_content['inner_tab_heading'] ) :
									print_element( 'heading', [
										'text'  => $block_content['inner_tab_heading'],
										'level' => 2,
										'class' => [ 'card-title', 'h2' ],
									] );
								endif;
								?>
								<?php if ( have_rows( 'candidate_inner_tabbing' ) ) : ?>
									<div class="inner-tab-panel">
										<ul class="tab-list-box">
											<?php
											$innerTabIndex   = 0; // Initialize a variable to keep track of the inner tab index
											$tabSlugs        = [];
											$phoneSectionIds = [];
											foreach ( $block_content['candidate_inner_tabbing'] as $prospective_client_tab ):
												$innerTabName = $prospective_client_tab[ 'inner_tab_name' ];
												$innerTabSlug = 'candidate-' . sanitize_title( $innerTabName );
												$tabSlugs[ $innerTabIndex ] = $innerTabSlug;

												if ( 0=== $innerTabIndex ) {
													$phoneSectionIds[$innerTabSlug] = 'background-accel-phone';
												} elseif( 1 === $innerTabIndex ) {
													$phoneSectionIds[$innerTabSlug] = 'background-ace-phone';
												} elseif ( 2 === $innerTabIndex ) {
													$phoneSectionIds[$innerTabSlug] = 'background-now-phone';
												}

												if ( ! empty( $innerTabName ) ) :
													?>
													<li class="tab-item-list">
														<div class="is-style-outline">
															<a href="#<?php echo $innerTabSlug; ?>" data-inner-tab-name="<?php echo $innerTabSlug; ?>" class="<?php echo $phoneSectionIds[ $innerTabSlug ]; ?> acf-element inner-tab-item-click acf-element-button has-background has-outline-pink-color has-color-pink"><?php echo $innerTabName; ?></a>
														</div>
													</li>
												<?php
												endif;
												$innerTabIndex++; // Increment the inner tab index for uniqueness
											endforeach;
											?>
										</ul>
										<?php if ( ! empty( $block_content['modal_info']['modal_link_title'] ) ) : ?>
											<div class="card-links">
												<a href="javascript:;" class="common-popup" id="<?php echo 'login_data' . $block['id']; ?>"><?php echo $block_content['modal_info']['modal_link_title']; ?></a>
											</div>
										<?php endif; ?>
										<?php
										if ( ! empty( $block_content['modal_info'] ) ) :
											$block_content['modal_info']["id"] = 'login_data' . $block['id'];
											print_module( 'modal-info', $block_content['modal_info'] );
										endif;
										?>
										<div class="inner-tab_content_container">
											<?php
											$innerTabContentIndex = 0;

											foreach ( $block_content['candidate_inner_tabbing'] as $candidate_tab ):
												$candidate_tab_inner_content = $candidate_tab[ 'inner_tab_conent' ];
												?>
												<div class="inner-tab-content" data-inner-tab="<?php echo $tabSlugs[ $innerTabContentIndex ]; ?>">
													<?php
													if ( ! empty( $candidate_tab_inner_content ) ) :
														print_element( 'content', [
															'content' => $candidate_tab_inner_content,
														] );
													endif;

													if ( $candidate_tab['inner_button'] ) :
														$buttons['class'] = [ 'contact-buttons' ];
														print_module( 'buttons-group', $candidate_tab['inner_button'] );
													endif;

													if ( $candidate_tab['inner_tab_form'] ) :
														echo do_shortcode( '[gravityform id="' . $candidate_tab['inner_tab_form'] . '" title="false" description="false" ajax="true"]' );
													endif;

													if ( ! empty( $candidate_tab['phone_title_candidate'] ) || ! empty( $candidate_tab['phone_number_candidate'] ) || ! empty( $candidate_tab['phone_2_number_candidate'] ) || ! empty( $candidate_tab['international_number_candidate'] ) || ! empty( $candidate_tab['main_heading_candidate'] ) || ! empty( $candidate_tab['main_description_candidate'] ) ) {
														if ( ! empty( $candidate_tab['phone_title_candidate'] ) || ! empty( $candidate_tab['phone_number_candidate'] ) || ! empty( $candidate_tab['phone_2_number_candidate'] ) || ! empty( $candidate_tab['international_number_candidate'] ) ) {
															$single_content_class = 'not-full';
														} else {
															$single_content_class = 'full';
														}

														$phone_section_id = 'candidate-phone-section-' . $innerTabContentIndex;
														$current_tab_slug = $tabSlugs[ $innerTabContentIndex ];

														if ( ! empty( $phoneSectionIds ) && array_key_exists( $current_tab_slug, $phoneSectionIds ) ) {
															$phone_section_id = $phoneSectionIds[ $current_tab_slug ];
														}
														?>
														<section id="<?php echo $phone_section_id; ?>" class="bg-primary-bright-blue section-padding text-white current-client-bottom">
															<div class="container">
																<div class="row <?php echo $single_content_class; ?>">
																	<?php if ( ! empty( $candidate_tab['main_heading_candidate'] ) || ! empty( $candidate_tab['main_description_candidate'] ) ) { ?>
																		<div class="col-md-5">
																			<div class="section-heading">
																				<?php if ( ! empty( $candidate_tab['main_heading_candidate'] ) ) { ?>
																					<h2 class="text-primary-orange"><?php echo $candidate_tab['main_heading_candidate']; ?></h2>
																				<?php } ?>
																				<?php if ( ! empty( $candidate_tab['main_description_candidate'] ) ) { ?>
																					<p class="desc large"><?php echo $candidate_tab['main_description_candidate']; ?></p>
																				<?php } ?>
																			</div>
																		</div>
																	<?php } ?>
																	<?php if ( ! empty( $candidate_tab['phone_title_candidate'] ) || ! empty( $candidate_tab['phone_number_candidate'] ) || ! empty( $candidate_tab['phone_2_number_candidate'] ) || ! empty( $candidate_tab['international_number_candidate'] ) ) { ?>
																		<div class="col-md-6 offset-md-1">
																			<div class="section-heading">
																				<?php if ( ! empty( $candidate_tab['phone_title_candidate'] ) ) { ?>
																					<p class="desc large text-primary-orange mb-1 font-weight-500"><?php echo $candidate_tab['phone_title_candidate']; ?></p>
																				<?php } ?>
																				<?php if ( ! empty( $candidate_tab['phone_number_candidate'] ) || ! empty( $candidate_tab['phone_2_number_candidate'] ) ) { ?>
																					<div class="phone_numbers">
																						<?php if ( ! empty( $candidate_tab['phone_number_candidate'] ) ) { ?>
																							<p class="desc"><?php echo $candidate_tab['phone_number_prefix_label_candidate']; ?>
																							&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $candidate_tab['phone_number_candidate'] ); ?>"><?php echo $candidate_tab['phone_number_candidate']; ?></a>
																							</p>
																						<?php } ?>
																						<?php if ( ! empty( $candidate_tab['phone_2_number_candidate'] ) ) { ?>
																							<p class="desc"><?php echo $candidate_tab['phone_2_number_prefix_label_candidate']; ?>
																							&nbsp;<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $candidate_tab['phone_2_number_candidate'] ); ?>"><?php echo $candidate_tab['phone_2_number_candidate']; ?></a>
																							</p>
																						<?php } ?>
																					</div>
																				<?php } ?>
																				<?php if ( ! empty( $candidate_tab['international_number_candidate'] ) ) { ?>
																					<div class="row">
																						<div class="col-lg-8">
																							<select class="custom-select custom-select-lg mb-3">
																								<option value="">INTERNATIONAL NUMBERS</option>
																								<?php foreach ( $candidate_tab['international_number_candidate'] as $numbers ) { ?>
																									<option value="<?php echo $numbers['number']; ?>"><?php echo $numbers['country_name']; ?></option>
																								<?php } ?>
																							</select>
																						</div>
																					</div>
																					<p class="desc">
																						<a href="" class="international-tel-number tel-link"></a>
																					</p>
																				<?php } ?>
																			</div>
																		</div>
																	<?php } ?>
																</div>
															</div>
														</section>
													<?php } ?>
												</div>
												<?php
												$innerTabContentIndex++;
											endforeach;
											?>
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>