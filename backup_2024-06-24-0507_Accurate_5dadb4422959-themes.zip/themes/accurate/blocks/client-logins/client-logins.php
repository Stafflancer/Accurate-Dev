<?php
/**
 * BLOCK: Client Logins
 *
 * @param array        $block      The block settings and attributes.
 * @param string       $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'client-logins-' . $block['id'],
	'class'    => [ 'acf-block', 'client-logins', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'client_login_buttons',
	'info_modal',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );

if ( !empty($block_content['client_login_buttons']) ) :?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="<?php echo esc_attr( $row_class ); ?>">
						<div class="col-md-12 col-sm-12">
							<div class="client-logins-box-outer"><?php
								foreach($block_content['client_login_buttons'] as $client_content) : ?>
									<div class="client-logins-box"><?php
										// Heading.
										if ( $client_content['heading'] ) :
											print_element( 'heading',[
												'text'  => $client_content['heading'],
												'level' => 4,
											]);
										endif;
										// Content.
										if ( !empty($client_content['content']) ) :
											print_element( 'content', [
												'content' => $client_content['content'],
												'class' => ['body-size-med']
											] ); 
										endif;
										// Button
										if ( !empty($client_content['button']) ) :
											$button = $client_content['button'];
											$button['class'] = [ 'common-popup'];
											$button['id'] = $block['id'];
											print_element( 'button', $button );
										endif; ?>
									</div><?php
								endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><?php
		if ( ! empty( $block_content['info_modal'] ) ) :
			$block_content['info_modal']["id"] = $block['id'];
			print_module(
				'modal-info',
				$block_content['info_modal']
			);
		endif; ?>
	</section>
	<div class="<?php echo $block['id']; ?>" style="display: none;"></div>
<?php endif; ?>