<?php
/**
 * BLOCK: Hero Banner - Partners (Detail)
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\get_trimmed_excerpt;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'hero-banner-partners-detail-' . $block['id'],
	'class'    => [ 'acf-block', 'hero-banner-partners-detail', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'buttons',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );
$featured_partner = get_field('featured_partner', get_the_ID());
$image = get_post_thumbnail_id();
$image_class = "";
$banner_heading = get_field('banner_heading', 'option');
$banner_content = get_field('banner_content', 'option');
$partner_banner_buttons = get_field('partner_banner_buttons', 'option');
if ( !empty($block_content['heading']) || !empty($block_content['content']) || !empty($block_content['buttons']) || !empty($banner_heading) || !empty($banner_content) || !empty($partner_banner_buttons)) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="breadcrumb">
						<ul class="breadcrumb-inner">
							<?php bcn_display(); ?>
						</ul>
					</div>
					<div class="content-hero-banner">
						<figure class="slider-transparent-img">
							<?php if ( ! empty( $image ) ) : ?>
								<?php echo wp_get_attachment_image( $image, 'medium', array( 'class' => esc_attr( $image_class ) ) ); ?>
							<?php else: ?>
								<img class="<?php echo esc_attr( $image_class ); ?>"
								     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
								     alt="Image Placeholder" width="764" height="764" aria-hidden="true">
							<?php endif; ?>
						</figure><?php
						if ( !empty($block_content['heading']) || !empty($block_content['content']) || !empty($block_content['buttons']) ) : ?>
							<div class="content-hero-banner-main"><?php
								if($featured_partner == 1) :
									print_element( 'tagline', [
										'text'  => 'PREMIERE PARTNER',
										'class' => 'label premiere-partner-icon',
									] );
								endif;
								// Heading.
								if ( !empty($block_content['heading']) ) :
									print_element(
										'heading',
										[
											'text'  => $block_content['heading'],
											'level' => 1,
											'class' => 'h2',
										]
									);
								else:
									if(!empty($banner_heading)){
										print_element(
											'heading',
											[
												'text'  => $banner_heading,
												'level' => 1,
												'class' => 'h2',
											]
										);
									}
								endif;
								// Content.
								if ( !empty($block_content['content']) ) :
									print_element(
										'content', [
										'content' => $block_content['content'],
										'class'   => 'body-size-large',
									] );
								else:
									if ( !empty($banner_content) ) {
										print_element(
											'content', [
											'content' => $banner_content,
											'class'   => 'body-size-large',
										] );
									}
								endif;
								// buttons
								if ( !empty($block_content['buttons']['buttons_group']) ) :
									$buttons = $block_content['buttons'];
									$buttons['class'] = [ 'hero-banner-partners-detail-btn' ];
									print_module(
										'buttons-group',
										$buttons
									);
								else:
									if ( !empty($partner_banner_buttons) ) { 
										$buttons = $partner_banner_buttons;
										$buttons['class'] = [ 'hero-banner-partners-detail-btn' ];
										print_module(
											'buttons-group',
											$buttons
										);
									}
								endif; ?>
							</div><?php
						endif;  ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>