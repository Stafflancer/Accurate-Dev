let $upcomingEventsCount = jQuery( '.upcoming-events-slider .slider-upcoming-events-item' ),
	sliderUpcomingEvents = new Swiper('.upcoming-events-slider', {
	loop: true,
	slidesPerView: 3,
	centeredSlides: true,
	spaceBetween: 20,
	watchSlidesProgress: true,
	breakpoints: {
		1024: {
			slidesPerView: 3,
			loop: $upcomingEventsCount.length > 3,
		},
		768: {
			slidesPerView: 2,
			loop: $upcomingEventsCount.length > 2,
		},
		480: {
			slidesPerView: 1,
			loop: $upcomingEventsCount.length > 1,
		},
		320: {
			slidesPerView: 1,
			loop: $upcomingEventsCount.length > 1,
		}
	},
	navigation: {
		nextEl: '.slider-upcoming-events .next',
		prevEl: '.slider-upcoming-events .prev',
	},
});