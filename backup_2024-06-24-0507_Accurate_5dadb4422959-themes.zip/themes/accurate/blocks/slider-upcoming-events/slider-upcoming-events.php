<?php
/**
 * BLOCK: Slider - Upcoming Events
 *
 * @param array        $block      The block settings and attributes.
 * @param string       $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'                  => ! empty( $block['anchor'] ) ? $block['anchor'] : 'slider-upcoming-events-' . $block['id'],
	'class'               => [ 'acf-block', 'slider-upcoming-events', 'position-relative' ],
	'allowed_innerblocks' => [ 'core/heading', 'core/paragraph' ],
	'settings'            => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'              => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	$column_size_class,
	'z-9',
] );
$row_class       = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );
$args            = array(
	'post_type'     => 'event',
	'post_status'   => 'publish',
	'post_per_page' => 12,
	'meta_query'    => array(
		// if no end date has been set use start date
		array(
			'key'     => 'start_date',
			'value'   => date( 'Ymd' ),
			'compare' => '>=',
			'type'    => 'DATE',
		),
	),
	'orderby'       => 'start_date',
	'order'         => 'ASC',
);
$the_query       = new WP_Query( $args );

if ( $the_query->have_posts() ) {
	$featured_count = 1;
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<?php if ( ! empty( $block_content['heading']['main_heading'] ) || ! empty( $block_content['content'] ) ) { ?>
						<div class="section-header-outer text-center">
							<?php
							// Heading
							if ( $block_content['heading'] ) :
								print_module( 'heading', [
									$block_content['heading'],
								] );
							endif;

							if ( $block_content['content'] ) :
								print_element( 'content', [
									'content' => $block_content['content'],
									'class'   => [ 'text', 'post-excerpt', 'm-0' ],
								] );
							endif;
							?>
						</div>
					<?php } ?>
					<div class="slider-arrow-outer">
						<div class="swiper upcoming-events-slider">
							<div class="swiper-wrapper">
								<?php
								while ( $the_query->have_posts() ) {
									$the_query->the_post();
									?>
									<div class="slider-upcoming-events-item swiper-slide">
										<?php echo print_module( 'card-event', [] ); ?>
									</div>
									<?php
									$featured_count++;
								}
								wp_reset_postdata();
								?>
							</div>
						</div>
						<div class="slider-arrows">
							<a href="javascript:" class="arrowbtn prev">
								<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
									<path d="M443.4,16.98h-7.788l-7.424,8.079,7.424,8.006H443.4l-7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
								</svg>
							</a>
							<a href="javascript:" class="arrowbtn next">
								<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
									<path d="M428.185,16.98h7.788l7.424,8.079-7.424,8.006h-7.788l7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
								</svg>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php } ?>