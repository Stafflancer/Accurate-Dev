var swiper = new Swiper(".home-banner-slider", {
    loop: false,
    slidesPerView: 1,
    spaceBetween: 10,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 1,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    navigation: {
      nextEl: '.next',
      prevEl: '.prev',
    },
    autoplay: {
        delay: 5500
    },
});