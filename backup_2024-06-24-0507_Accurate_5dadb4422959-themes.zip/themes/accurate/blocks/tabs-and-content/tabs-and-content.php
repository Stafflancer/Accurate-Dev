<?php
/**
 * BLOCK: Tabs and Content
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'tabs-and-content-' . $block['id'],
	'class'    => [ 'acf-block', 'tabs-and-content-main', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'tabs'
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].' col-sm-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );


if ( !empty( $block_content['heading'] ) || !empty( $block_content['content'] ) || !empty( $block_content['tabs'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class=" <?php echo esc_attr( $column_class ); ?>">
					<div class="section-header-outer text-center"><?php
						//	Heading
						if ( $block_content['heading'] ) :
							print_module('heading',[
								$block_content['heading']
							]);
						endif;
						if ( $block_content['content'] ) :
							print_element( 'content', [
								'content' => $block_content['content'],
								'class'   => [ 'text', 'post-excerpt', 'm-0' ],
							] );
						endif; ?>
					</div><?php
						if(!empty($block_content['tabs'])){ 
							$counter = 1; ?>
							<div class="tabbed-content">
								<ul class="tabs-content"><?php
									foreach($block_content['tabs'] as $tabs){ 
										$tab_name = $tabs['tab_name']; 
										if(!empty($tab_name)){ ?>
											<li class="tab-link <?php if($counter == 1){ echo 'current'; } ?>" data-tab="tab-<?php echo $counter; ?>"><?php echo $tab_name; ?>
											</li><?php
										}
										$counter++;
									} ?>
								</ul>
								<div class="tabs-body"><?php
								$index = 1;
								foreach($block_content['tabs'] as $tabs){ 
									$heading = $tabs['heading'];
									$content = $tabs['content'];
									$image = $tabs['image']; ?>
									<div id="tab-<?php echo $index; ?>" class="tab-content-data <?php if($index == 1){ echo 'current'; } ?>"><div class="tab-inner-main">
											<?php if ( ! empty( $image ) ) : 
												$image_class = ''; ?>
												<figure class="card-image-img">
													<?php echo wp_get_attachment_image( $image, 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
												</figure>
											<?php endif; ?><?php
											// Heading.
											if ( $heading ) :
												print_element( 'heading', [
													'text'  => $heading,
													'level' => 3,
													'class' => [ 'event-title', 'h3' ],
												] );
											endif; 
											// Content.
											if ( $content ) :
												print_element( 'content', [
														'content' => $content, 
												]);
											endif; ?>
										</div></div><?php
										$index++;
									} ?>
								</div>
							</div><?php
						} ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
