var swiper = new Swiper(".side-by-side-slider", {
    loop: false,
    slidesPerView: 1,
    spaceBetween: 25,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 1,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    pagination: {
      el: ".swiper-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 5500
    },
});