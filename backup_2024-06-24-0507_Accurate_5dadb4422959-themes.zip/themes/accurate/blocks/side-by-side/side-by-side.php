<?php
/**
 * BLOCK: Side by Side
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'side-by-side-' . $block['id'],
	'class'    => [ 'acf-block', 'side-by-side', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'content_layout',
	'content',
	'media',
	'content_alignment',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'inner-container-width cols-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );

$row_class    = join( ' ', [
	'row justify-content-between',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

$slider_counter = '';
if ( ! empty( $block_content['media'] ) ) {
	$images = $block_content['media']['images'];
	if ( ! empty( $images ) ) {
		$slider_counter = count( $images );
	}
	$videos = $block_content['media']['videos'];
	if ( ! empty( $videos ) ) {
		$slider_counter = count( $videos );
	}
}
$accent_position_class = '';
if ( ! empty( $block_content['content']['heading']['accent_position'] ) && $block_content['content']['heading']['accent_position'] == 'left' ) {
	$accent_position_class = 'left-side-line-added';
}
if ( ! empty( $block_content['content'] ) || ! empty( $block_content['media'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> z-10 position-relative">
			<div class="row">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="<?php echo esc_attr( $row_class ); ?> <?php if ( $block_content['content_layout'] == 'content-image' ) {
							echo 'flex-row-reverse';
						} ?> <?php if ( $slider_counter > 1 ) {
							echo 'align-items-center';
						} ?> <?php echo $block_content['content_alignment']; ?>">
						<?php if ( ! empty( $block_content['media'] ) ) : ?>
							<div class="col-lg-5 col-md-6 col-lg-5 col-sm-12">
							<?php
							$media_type = $block_content['media']['media_type'];
							if ( $media_type == 'image' ) {
								$images = $block_content['media']['images'];
								if ( ! empty( $images ) ) :
									?>
									<div class="swiper side-by-side-slider">
										<div class="swiper-wrapper grid-block">
											<?php
											$image_class = 'img-top-way';
											foreach ( $images as $image ) :
												?>
												<div class="swiper-slide side-by-side-slider-outer">
													<?php echo wp_get_attachment_image( $image, 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
												</div>
											<?php endforeach; ?>
										</div>
										<div class="swiper-pagination"></div>
									</div>
								<?php
								endif;
							} else {
								$videos = $block_content['media']['videos'];
								if ( ! empty( $videos ) ) : ?>
									<div class="swiper side-by-side-slider">
										<div class="swiper-wrapper">
											<?php
											foreach ( $videos as $video ) :
												$iframe = $video['video'];
												preg_match( '/src="(.+?)"/', $iframe, $matches );
												$src = $matches[1]; ?>
												<div class="swiper-slide side-by-side-slider-outer">
													<?php
													// Add extra parameters to src and replace HTML.
													$params  = array(
														'controls' => 1,
														'hd'       => 1,
														'autohide' => 1,
													);
													$new_src = add_query_arg( $params, $src );
													$iframe  = str_replace( $src, $new_src, $iframe );

													// Add extra attributes to iframe HTML.
													$attributes = 'frameborder="0"';
													$iframe     = str_replace( '></iframe>', ' ' . $attributes . '></iframe>', $iframe );

													// Display customized HTML.
													echo $iframe;
													?>
												</div>
											<?php endforeach; ?>
										</div>
										<div class="swiper-pagination"></div>
									</div>
								<?php
								endif;
							}
							?>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $block_content['content'] ) ) : ?>
							<div class="col-lg-6 col-md-6 col-sm-12 <?php echo $accent_position_class; ?>">
								<div class="text-box">
									<?php
									$tagline         = $block_content['content']['tagline'];
									$heading         = $block_content['content']['heading'];
									$excerpt_content = $block_content['content']['content'];
									$buttons         = $block_content['content']['buttons'];
									// Tagline
									if ( $tagline ) :
										print_element( 'tagline', [
											'text'  => $tagline,
											'level' => 2,
										] );
									endif;
									//	Heading
									if ( $heading ) :
										print_module( 'heading', [
											$heading,
										] );
									endif;
									if ( $excerpt_content ) :
										print_element( 'content', [
											'content' => $excerpt_content,
											'class'   => [ 'text', 'post-excerpt', 'm-0' ],
										] );
									endif;
									// buttons
									if ( $buttons ) :
										$buttons['class'] = [ '' ];
										print_module( 'buttons-group', $buttons );
									endif;
									?>
								</div>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>