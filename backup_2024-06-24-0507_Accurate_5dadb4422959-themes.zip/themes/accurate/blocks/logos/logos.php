<?php
/**
 * BLOCK: Logos
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'logos-' . $block['id'],
	'class'    => [ 'acf-block', 'logos-main', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'number_of_columns',
	'clients',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );

$row_class    = join( ' ', [
	'row',
] );

$column_class = join( ' ', [
	$column_size_class,
] );

$classes      = '';

if ( $block_content['number_of_columns'] == 4 ) {
	$classes = 'logo-4';
} elseif ( $block_content['number_of_columns'] == 5 ) {
	$classes = 'logo-5';
} elseif ( $block_content['number_of_columns'] == 6 ) {
	$classes = 'logo-6';
} else {
	$classes = 'logo-7';
}
if ( ! empty( $block_content['heading'] ) || ! empty( $block_content['slider'] ) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<?php if ( array_key_exists( 'main_heading', $block_content['heading'] ) && ! empty( $block_content['heading']['main_heading'] ) ) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?> justify-content-center">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-outer">
							<?php
							// Heading
							if ( $block_content['heading'] ) :
								print_module( 'heading', [
									$block_content['heading'],
								] );
							endif;
							?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $block_content['clients'] ) ) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="col-md-12 col-sm-12">
						<div class="cards">
							<div class="slider-arrow-outer mobile-view">
								<div class="swiper logos-slider <?php echo $classes; ?>">
									<div class="swiper-wrapper">
										<?php
										global $post;
										foreach ( $block_content['clients'] as $post ):
											setup_postdata( $post );
											?>
											<div class="swiper-slide">
												<?php
												if ( ! empty( get_post_thumbnail_id() ) ) :
													$image_class = 'logo';
													?>
													<figure class="overflow-hidden">
														<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
													</figure>
												<?php endif; ?>
											</div>
										<?php
										endforeach;
										wp_reset_postdata();
										?>
									</div>
								</div>
								<div class="slider-arrows">
									<a href="javascript:" class="arrowbtn prev">
										<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
										  <path d="M443.4,16.98h-7.788l-7.424,8.079,7.424,8.006H443.4l-7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
										</svg>
									</a>
									<a href="javascript:" class="arrowbtn next">
										<svg xmlns="http://www.w3.org/2000/svg" width="15.212" height="16.085" viewBox="0 0 15.212 16.085">
										  <path d="M428.185,16.98h7.788l7.424,8.079-7.424,8.006h-7.788l7.424-8.006Z" transform="translate(-428.185 -16.98)"></path>
										</svg>
									</a>
								</div>
							</div>
							<div class="desktop-view logos-main-flex <?php echo $classes; ?>">
								<?php
								global $post;
								foreach ( $block_content['clients'] as $post ):
									setup_postdata( $post );
									?>
									<div class="col">
										<?php
										if ( ! empty( get_post_thumbnail_id() ) ) :
											$image_class = 'logo';
											?>
											<figure class="overflow-hidden">
												<?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
											</figure>
										<?php endif; ?>
									</div>
								<?php
								endforeach;
								wp_reset_postdata();
								?>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>