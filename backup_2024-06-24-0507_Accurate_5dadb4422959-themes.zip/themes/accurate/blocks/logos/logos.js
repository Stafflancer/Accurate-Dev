let $ = jQuery.noConflict();
$(function() {
	const $window = $(window);
	const swiper = new Swiper('.logos-slider', {
		init: false,
		loop: true,
		slidesPerView: 2,
		spaceBetween: 15,
		watchSlidesProgress: true,
		breakpoints: {
			slidesPerView: 2,
		},
		navigation: {
			nextEl: '.logos-main .next',
			prevEl: '.logos-main .prev',
		},
	});

	$window.on('load', function(){
		if ($window.width() < 768) {
			swiper.init();
		}
	}).on('resize', function(){
		if ($window.width() < 768) {
			swiper.init();
		} else {
			swiper.destroy();
		}
	});
});