<?php
/**
 * BLOCK: Hero Banner - Video
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'hero-banner-video-' . $block['id'],
	'class'    => [ 'acf-block', 'hero-banner-video', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'description',
	'buttons',
	'video'
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );

if ( !empty($block_content['heading']) || !empty($block_content['description']) || !empty($block_content['buttons']) || !empty($block_content['video']) ) :
	?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="breadcrumb">
						<ul class="breadcrumb-inner">
							<?php bcn_display(); ?>
						</ul>
					</div>
					<div class="content-hero-banner">
						<div class="content-hero-banner-main"><?php
							// Heading.
							if ( $block_content['heading'] ) :
								print_module('heading',[
									$block_content['heading']
								]);
							endif;
							// Content.
							if ( $block_content['description'] ) :
								print_element(
									'content', [
									'content' => $block_content['description'],
									'class'   => 'body-size-large',
								] );
							endif;
							// button
							if ( $block_content['buttons'] ) :
								$buttons = $block_content['buttons'];
								$buttons['class'] = [ 'hero-banner-video-btn' ];
								print_module(
									'buttons-group',
									$buttons
								);
							endif;
						?>
						</div>
					</div>
				</div>
			</div>
		</div><?php
		if(!empty($block_content['video'])){ ?>
			<div class="modal fade modal-info" id="hero-banner-video-popup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display: none;">
				<div class="modal-dialog" role="document">
				    <div class="modal-content">
				      	<div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true" class="cross-btn modal-cross-btn">&times;</span>
					        </button>
				    	</div>
					    <div class="modal-body" id="youtube-player"><?php
					      	// Use preg_match to find iframe src.
							preg_match('/src="(.+?)"/', $block_content['video'], $matches);
							$src = $matches[1];

							// Add extra parameters to src and replace HTML.
							$params = array(
							    'controls'  => 0,
							    'hd'        => 1,
							    'autohide'  => 1
							);
							$new_src = add_query_arg($params, $src);
							$iframe = str_replace($src, $new_src, $block_content['video']);

							// Add extra attributes to iframe HTML.
							$attributes = 'frameborder="0"';
							$attributes = 'id="hero_banner_iframe"';
							$iframe = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $iframe);

							// Display customized HTML.
							echo $iframe; ?>
					    </div>
				    </div>
				</div>
			</div><?php
		} ?>
	</section>
<?php endif; ?>