jQuery(document).ready(function ($) {
	jQuery('.hero-banner-video-btn').click(function ($) {
		jQuery('#hero-banner-video-popup').show();
		jQuery('body').addClass('modal-open');
	});

	jQuery('.modal-cross-btn').click(function ($) {
		jQuery('#hero-banner-video-popup').hide();
		jQuery('body').removeClass('modal-open');
		var iframe = jQuery(this).parent('button').parent('.modal-header').next('.modal-body').children('iframe').attr('src');
		/*var id = extractYouTubeVideoID(iframe);
		jQuery(this).parent('button').parent('.modal-header').next('.modal-body').children('iframe').attr('height', '390');
		var player = new YT.Player('youtube-player', {
		  videoId: id, // Replace with your YouTube video ID
		  events: {
			  'onReady': onPlayerReady
		  }
		  });

			if (player) {
				  player.pauseVideo();
		  }*/
	});
});

function onPlayerReady(event) {
	// You can now interact with the player
}

function extractYouTubeVideoID(iframe) {
	// Use regular expression to match the video ID
	var match = iframe.match(/embed\/([A-Za-z0-9_-]+)/);

	if (match && match.length > 1) {
		return match[1]; // Extracted video ID
	} else {
		return null; // URL is not in the expected format
	}
}