jQuery(document).ready(function($)
{
	jQuery(".press-kit-btn").click(function($) {
	  var finded = jQuery(this).attr('data-id');
	  jQuery('.press-kit-'+finded).show(); 
	  jQuery('body').addClass('modal-open');
	});

	jQuery(".press-kit-cross").click(function($) {
	  var finded = jQuery(this).attr('data-id');
	  jQuery('.press-kit-'+finded).hide(); 
	   jQuery('body').removeClass('modal-open');
	});
});