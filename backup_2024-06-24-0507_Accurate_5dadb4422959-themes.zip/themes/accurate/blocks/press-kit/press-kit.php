<?php
/**
 * BLOCK: Press Kit
 *
 * @param array        $block      The block settings and attributes.
 * @param string       $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'press-kit-' . $block['id'],
	'class'    => [ 'acf-block', 'press-kit', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'downloads',
	'media_contact',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'inner-container-width cols-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );
$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] );
if ( !empty($block_content['heading']) || !empty($block_content['content']) || !empty($block_content['downloads']) || !empty($block_content['media_contact']) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="<?php echo esc_attr( $row_class ); ?>">
						<div class="col-md-12 col-sm-12"><?php
							if ( array_key_exists("main_heading",$block_content['heading']) && !empty($block_content['heading']['main_heading']) || !empty($block_content['content'])) : ?>
								<div class="section-header-outer text-center mb-5"><?php
									if ( $block_content['heading'] ) :
										print_module('heading',[
											$block_content['heading']
										]);
									endif;
									// Content.
									if ( !empty($block_content['content']) ) :
										print_element( 'content', [
											'content' => $block_content['content'],
										] );
									endif; ?>
								</div><?php
							endif; ?>
							<div class="press-kit-box"><?php
								if ( !empty($block_content['downloads']) ){ 
									$index = 1; ?>
									<div class="downloads"><?php
										foreach($block_content['downloads'] as $downloads){
											$image = $downloads['image'];
											$heading = $downloads['heading'];
											$subheading = $downloads['subheading'];
											$link_type = $downloads['link_type'];
											$link = $downloads['link'];
											$modal_content = $downloads['modal_content']; ?>
											<div class="downloads-item"><?php 
												if ( ! empty( $image ) ) : 
													$image_class = ''; ?>
													<?php echo wp_get_attachment_image( $image, 'medium', array( 'class' => esc_attr( $image_class ) ) ); 
												endif; ?>
												<div class="downloads-item-text">
													<div class="item-text-main"><?php 
														// Heading.
														if ( $heading ) :
															print_element( 'heading', [
																'text'  => $heading,
																'level' => 3,
																'class' => [ 'card-title', 'h3' ],
															] );
														endif; 
														// Heading.
														if ( $subheading ) :
															print_element( 'heading', [
																'text'  => $subheading,
																'level' => 4,
																'class' => [ 'card-title', 'h4' ],
															] );
														endif; ?>
													</div><?php
													if($link_type == 'link'){ ?>
														<div class="card-links">
															<a href="<?php echo $link['url']; ?>" class="acf-element acf-element-anchor stretched-link"><?php echo $link['title'].'<span> > </span>'; ?></a>
														</div><?php
													}  
													else{ ?>
														<div class="card-links">
															<a href="javascript:;" class="acf-element acf-element-anchor press-kit-btn stretched-link" data-id="<?php echo $index; ?>">View/Download <span> > </span></a>
														</div>
														<div class="press-kit-modal modal-info press-kit-<?php echo $index; ?>" style="display:none;">
															<div class="modal fade " id="press-kit-<?php echo $index; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
															  <div class="modal-dialog" role="document">
															    <div class="modal-content">
															      <div class="modal-header">
															        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
															          <span aria-hidden="true" class="cross-btn press-kit-cross" data-id="<?php echo $index; ?>">&times;</span>
															        </button>
															      </div>
															      <div class="modal-body"><?php
															     	// Heading.
																	if ( $modal_content['modal_heading'] ) :
																		print_element( 'heading', [
																			'text'  => $modal_content['modal_heading'],
																			'level' => 2,
																			'class' => [ 'card-title', 'h2' ],
																		] );
																	endif;
																	// Content.
																	if ( $modal_content['modal_content'] ) :
																		print_element( 'content', [
																			'content' => $modal_content['modal_content'],
																			'class'   => [ 'card-text', 'post-excerpt', 'm-0' ],
																		] );
																	endif; 
																	// Form.
																	if ( $modal_content['modal_form'] ) : ?>
																		<div class="modal-form"><?php
																			echo do_shortcode( '[gravityform id="' . $modal_content['modal_form'] . '" title="false" description="false" ajax="true"]' ); ?>
																		</div><?php
																	endif;  ?>
															      </div>
															    </div>
															  </div>
															</div>
														</div><?php
													} ?>
												</div>
											</div><?php
											$index++;  
										} ?> <?php
										if(!empty($block_content['media_contact'])){ ?>
											<div class="media-contact"><?php
												// Heading.
												if ( $block_content['media_contact']['heading'] ) :
													print_element( 'heading', [
														'text'  => $block_content['media_contact']['heading'],
														'level' => 4,
														'class' => [ 'card-title', 'h4' ],
													] );
												endif;
												// Content.
												if ( $block_content['media_contact']['content'] ) :
													print_element( 'content', [
														'content' => $block_content['media_contact']['content'],
														'class'   => [ 'card-text', 'post-excerpt', 'm-0' ],
													] );
												endif;  
												if ( $block_content['media_contact']['email'] ) :
													print_element( 'anchor', [
														'text'  => $block_content['media_contact']['email'],
														'href'  => 'mailto:'.$block_content['media_contact']['email'],
														'class' => 'email',
													] );
												endif;
												if ( $block_content['media_contact']['phone'] ) :
													print_element( 'anchor', [
														'text'  => $block_content['media_contact']['phone'],
														'href'  => 'tel:'.$block_content['media_contact']['phone'],
														'class' => 'phone',
													] );
												endif; ?>
											</div><?php
										} ?>
									</div><?php 
								} ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>