<?php /* Template name: Quick Links */

get_header();

use function BopDesign\bopper\get_main_classes; 
use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$quick_links = get_field('quick_links'); 
if(!empty($quick_links)) : ?>
	<section class="quick-links-main">
		<div class="container">
			<div class="quick-links-main-inner"><?php
				foreach($quick_links as $links) :
					if ( $links['button'] ) :
						$button = $links['button'];
						$buttons['class'] = [ 'common-btn', 'button-quick-links' ];
						print_element(
							'button',
							$button
						);
					endif;  
				endforeach; ?>
			</div>
		</div>
	</section>
	<div class="link-btn">
		<a href="javascript:;" class="acf-element acf-element-anchor quick-links ">QUICK LINKS <svg xmlns="http://www.w3.org/2000/svg" width="21.5" height="21.501" viewBox="0 0 21.5 21.501">
	  <g id="Group_108765" data-name="Group 108765" transform="translate(-1589.5 -303.499)">
	    <path id="Subtraction_4" data-name="Subtraction 4" d="M21.5,21.5H0L6.371,15.13H15.13V6.37L21.5,0V21.5Z" transform="translate(1589.5 303.499)" fill="#97a3ae"/>
	  </g>
</svg>
</a>
	</div><?php
endif; ?>
<main id="main" class="<?php echo esc_attr( get_main_classes( [] ) ); ?>" role="main"><?php
	while ( have_posts() ) :
		the_post();

		get_template_part( 'template-parts/content', 'page' );

	endwhile; // End of the loop. ?>
</main><!-- #main -->

<?php
get_footer();