<?php
/**
 * Template name: Thank You
 */

get_header();
use function BopDesign\bopper\get_main_classes;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$heading                               = get_field( 'heading' );
$content                               = get_field( 'content' );
$accel_heading                         = get_field( 'accel_heading' );
$accel_content                         = get_field( 'accel_content' );
$accel_button                          = get_field( 'accel_button' );
$phone_number_heading                  = get_field( 'phone_number_heading' );
$accel_phone_number_prefix_label       = get_field( 'accel_phone_number_prefix_label' );
$accel_phone_number                    = get_field( 'accel_phone_number' );
$accel_phone_number_2                  = get_field( 'accel_phone_number_2' );
$candidate_footer_international_number = get_field( 'candidate_footer_international_number' );
?>
	<main id="main" class="<?php echo esc_attr( get_main_classes( [] ) ); ?>" role="main">
		<section class="acf-block position-relative contact-banner-home overflow-hidden has-text-white-color has-tagline-white-color has-heading-white-color has-background gradient-as-background has-blue-background-color alignfull mt-0 mb-0">
			<div class="pattern-position-right">
				<figure class="has-pattern-show" aria-hidden="true">
					<img decoding="async" src="/wp-content/uploads/2023/08/HeroAccent-UpperRight-1.png" alt="">
				</figure>
			</div>
			<div class="container z-9">
				<div class="row">
					<div class="col-md-11 col-sm-12">
						<div class="breadcrumb">
							<ul class="breadcrumb-inner">
								<?php bcn_display(); ?>
							</ul>
						</div>
						<?php if ( !empty($heading) || !empty($content) ) : ?>
							<div class="section-heading">
							<?php
								// Heading
								if ( $heading ) :
									print_module('heading',[
										$heading
									]);
								endif;

								// Content.
								if ( !empty($content) ) :
									print_element( 'content', [
										'content' => $content,
										'class' => [ 'body-size-large'],
									] );
								endif;
								?>
							</div>
						<?php endif; ?>
					</div>
					<div class="col-md-11 col-sm-12">
						<div class="contact-banner-outer">
							<div class="form-left-head">
								<?php
								// Heading.
								if ( $accel_heading ) :
									echo '<h3>'.$accel_heading.'</h3>';
								endif;

								// Content.
								if ( !empty($accel_content) ) :
									print_element( 'content', [
										'content' => $accel_content,
									] );
								endif;

								// Button
								if ( !empty($accel_button) ) :
									$button = $accel_button;
									print_element( 'button', $button );
								endif;
								?>
							</div>
							<div class="form-right">
								<div class="phone_numbers">
									<?php
									// Heading.
									if ( $phone_number_heading ) :
										print_element( 'heading', [
											'text'  => $phone_number_heading,
											'level' => 4,
											'class' => [ 'card-title', 'h4' ],
										] );
									endif;
									?>

									<?php if ( ! empty( $accel_phone_number ) ) { ?>
										<p class="desc"><?php echo $accel_phone_number_prefix_label; ?>&nbsp;
											<a class="tel-link" href="tel:<?php echo str_replace(['(',')',' ','-'],'',$accel_phone_number); ?>"><?php echo $accel_phone_number; ?></a>
										</p>
									<?php } ?>

									<?php if ( ! empty( $accel_phone_number_2 ) ) { ?>
										<p class="desc">
											<a class="tel-link" href="tel:<?php echo str_replace( [ '(', ')', ' ', '-', ], '', $accel_phone_number_2 ); ?>"><?php echo $accel_phone_number_2; ?></a>
										</p>
									<?php } ?>
								</div>
								<?php if ( have_rows( 'candidate_footer_international_number' ) ) { ?>
									<div class="custom-select-country">
										<label for="country">Country</label>
										<select id="country" class="custom-select custom-select-lg">
											<option value="">INTERNATIONAL NUMBERS</option>
											<?php while ( have_rows( 'candidate_footer_international_number' ) ) : the_row(); ?>
												<option value="<?php the_sub_field( 'number' ); ?>"><?php the_sub_field( 'country_name' ); ?></option>
											<?php endwhile; ?>
										</select>
										<p class="desc">
											<a href="" class="international-tel-number tel-link"></a>
										</p>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );
		endwhile; // End of the loop.
		?>
	</main><!-- #main -->
<?php
get_footer();