<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bopper
 */

use function BopDesign\bopper\print_copyright_text;
use function BopDesign\bopper\print_social_media;
use function BopDesign\bopper\print_mobile_menu;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_address;
use function BopDesign\bopper\print_footer_logos; ?>

<footer id="colophon" class="site-footer" role="contentinfo">
	<div class="container">
		<div class="row">
			<?php if ( has_nav_menu( 'footer' ) ) : ?>
				<div class="col-12 col-md-12 col-lg-6">
					<nav id="site-footer-navigation" class="footer-navigation footer-left" aria-label="<?php esc_attr_e( 'Footer Navigation', THEME_TEXT_DOMAIN ); ?>">
						<ul id="footer-menu" class="footer-menu menu">
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer',
									'items_wrap'     => '%3$s',
									'container'      => false,
									'link_before'    => '<span>',
									'link_after'     => '</span>',
									'fallback_cb'    => false,
								)
							);
							?>
						</ul><!-- .footer-navigation-wrapper -->
					</nav>
				</div><!-- .footer-navigation -->
			<?php endif; ?>
			<div class="col-12 col-md-6 col-lg-3">
				<nav id="site-footer-navigation-2" class="footer-navigation footer-right" aria-label="<?php esc_attr_e( 'Footer Navigation', THEME_TEXT_DOMAIN ); ?>">
					<ul id="footer-menu" class="footer-menu menu">
						<?php
						wp_nav_menu(
							array(
								'menu' => 'Footer Menu - Secondary',
								'items_wrap'     => '%3$s',
								'container'      => false,
								'link_before'    => '<span>',
								'link_after'     => '</span>',
								'fallback_cb'    => false,
							)
						);
						?>
					</ul><!-- .footer-navigation-wrapper -->
				</nav>
			</div><!-- .footer-navigation -->
			<?php
			$phones = get_field('phones', 'option');
			$contact_button = get_field('contact_button', 'option');
			?>
			<div class="col-12 col-md-6 col-lg-3">
				<?php print_footer_logos(); ?>
				<div class="footer-last-col">
					<?php
					print_address();
					if ( ! empty( $phones ) ) {
						?>
						<div class="phones">
							<?php foreach ( $phones as $phone ) { ?>
								<div class="contact-info">
									<?php
									if ( $phone['phone_name'] ) :
										print_element( 'heading', [
											'text'  => $phone['phone_name'],
											'level' => 6,
											'class' => [ 'phone-title', 'h4' ],
										] );
									endif;

									if ( $phone['phone_number'] ) : ?>
										<a href="<?php echo $phone['phone_number']['url']; ?>"><?php echo $phone['phone_number']['title']; ?></a>
									<?php endif; ?>
								</div>
							<?php } ?>
						</div>
						<?php
					}
					$buttons          = $contact_button;
					$buttons['class'] = [ 'cta-btn' ];
					print_module( 'buttons-group', $buttons );
					?>
					<?php print_social_media(); ?>
				</div>
			</div>
		</div>
		<div class="copy-right-top">
			<div class="row">
				<div class="col-md-12 col-sm-12 align-self-center">
					<div class="site-info has-color-dark-gray">
						<?php print_copyright_text(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer><!-- #colophon -->

<?php print_mobile_menu(); ?>
<?php wp_footer(); ?>
</body>
</html>