<?php
/**
 * MODULE: Team Members
 * Template part for displaying reusable card in blocks and archives.
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;
use function BopDesign\bopper\print_svg;

$module_defaults = [
	'class'   => [
		'col-lg-4 col-md-4 col-sm-6',
	],
	'image'   => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'excerpt' => false, // get_trimmed_excerpt( [ 'post' => get_the_ID(), ] )
	'title' 	  => get_field('title', get_the_ID()),
	'linkedin' 	  => get_field('linkedin', get_the_ID()),
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'circle'; ?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>	
	<div class="acf-module acf-module-postcard testimonials-card">
		<div class="card-inner">
			<figure class="team-member-img"><?php 
				if ( ! empty( $module_args['image'] ) ) : ?>
					<?php echo wp_get_attachment_image( $module_args['image'], 'large', array( 'class' => esc_attr( $image_class ) ) ); 
				else: ?>
					<img class="<?php echo esc_attr( $image_class ); ?>" src="<?php echo get_theme_file_uri( '/assets/images/ExampleHeadshot-2.png' ); ?>" alt="Image Placeholder" width="764" height="764" aria-hidden="true"><?php
				endif; ?>
			</figure>
			<div class="team-member-details"><?php
			if ( $module_args['linkedin'] ): ?>
				<a href="<?php echo esc_url( $module_args['linkedin'] ); ?>" class="social-icon rounded-circle has-blue-background-color">
					<?php
					print_svg( [
						'icon'   => 'linkedin',
						'width'  => '24',
						'height' => '24',
					] );
					?>
					<span class="screen-reader-text">
						<?php
						/* translators: the social network name */
						printf( esc_attr__( 'Link to %s', THEME_TEXT_DOMAIN ), ucwords( esc_html( 'linkedin' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
						?>
					</span>
				</a><?php 
			endif;
			// Heading.
			if ( $module_args['heading'] ) :
				print_element( 'heading', [
					'text'  => $module_args['heading'],
					'level' => 4,
					'class' => [ 'card-title', 'h4' ],
				] );
			endif;

			// Content.
			if ( $module_args['title'] ) :
				print_element( 'content', [
					'content'  => $module_args['title'],
					'class'   => [ 'company-name', 'post-excerpt', 'm-0' ],
				] );
			endif;
			 ?>
			</div>
		</div>
	</div>
</div>
