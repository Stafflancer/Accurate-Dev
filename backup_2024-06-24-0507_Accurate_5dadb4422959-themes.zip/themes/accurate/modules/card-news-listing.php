<?php
/**
 * MODULE: Card - News & Press
 * Template part for displaying reusable card in blocks and archives.
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-card-transparent',
		'card hover-image-zoom',
		'has-background-color',
	],
	'image'   => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
	'button'  => [
		'title'  => 'Read More',
		'url'    => get_the_permalink(),
		'target' => false,
		'class'  => [ 'stretched-link' ],
	],
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top';

$news_type = get_the_terms( get_the_ID(), 'news_type' );
$terms_news_type = join( ' | ', wp_list_pluck( $news_type, 'name' ) ); ?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="card-body">
		<div class="card-text"><?php
			if(!empty($terms_news_type)){ ?>
				<label><?php echo $terms_news_type; ?></label><?php
			} ?>
			<div class="card-text-date"><?php
				print_element( 'tagline', [
					'text'  => get_the_author(),
					'class' => 'p',
				] );
				echo '<span>  |  </span>';
				print_element( 'tagline', [
					'text'  => get_the_date(),
					'class' => 'p',
				] ); ?>
			</div>
			<div class="card-links">
				<a href="<?php echo $module_args['button']['url']; ?>" class="acf-element acf-element-anchor stretched-link"><?php echo $module_args['heading'].'<span> > </span>'; ?></a>
			</div>
		</div>
	</div>
</div>
