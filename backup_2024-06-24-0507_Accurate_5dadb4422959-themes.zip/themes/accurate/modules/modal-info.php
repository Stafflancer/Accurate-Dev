<?php
/**
 * MODULE: Info Modal
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$module_defaults = [
	'class'      => [ 'acf-module', 'modal-info', 'collapsDiv faqs-pannel-tab faq-toggle' ],
	'id'		=> false,
	'modal_link_title' => false,
	'modal_heading' => false,
	'modal_content' => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top w-100 h-100 object-cover object-center'; ?>

<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="modal fade <?php echo $module_args['id']; ?>" id="<?php echo $module_args['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display: none;">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true" class="cross-btn" data-id="<?php echo $module_args['id']; ?>">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body"><?php
	     	// Heading.
			if ( $module_args['modal_heading'] ) :
				print_element( 'heading', [
					'text'  => $module_args['modal_heading'],
					'level' => 2,
					'class' => [ 'card-title', 'has-heading-navy-color' ],
				] );
			endif;
			// Content.
			if ( $module_args['modal_content'] ) :
				print_element( 'content', [
					'content' => $module_args['modal_content'],
					'class'   => [ 'card-text', 'post-excerpt', 'has-text-dark-gray-color' ],
				] );
			endif;  ?>
	      </div>
	    </div>
	  </div>
	</div>
</div>
