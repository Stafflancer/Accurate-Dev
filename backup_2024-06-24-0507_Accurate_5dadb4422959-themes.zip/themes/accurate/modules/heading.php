<?php
/**
 * ELEMENT: Heading
 *
 * Elements are analogous to 'Atoms' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#atoms
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults  = [
	'class' => [ 'acf-element', 'acf-element-heading' ],
	'main_heading'    => false,
	'heading_size'    => false,
	'accent'    => false,
	'accent_position' => false,
	'bottom_accent_position' => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );
if ( !empty($module_args[0]['main_heading'] ) ) : 
	$accent_position = '';
	$bottom_accent_position = '';
	if($module_args[0]['accent'] == 1) :
		$accent_position = 'accent-position-'.$module_args[0]['accent_position'];
	endif;
	$bottom_accent_position = 'bottom-accent-position-'.$module_args[0]['bottom_accent_position']; ?>
	<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php
		// Heading.
		if ( $module_args[0]['main_heading'] ) :
			echo '<'.$module_args[0]['heading_size'].' class="'.$accent_position.' '.$bottom_accent_position.' clone-heading">'.$module_args[0]['main_heading'].'</'.$module_args[0]['heading_size'].'>';
		endif; ?>
	</div><?php
endif; 