<?php
/**
 * MODULE: Open Position
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'      => [ 'acf-module', 'acf-module-postcard' ],
	'image'    => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'salary' => get_field('salary', get_the_ID()),
	'deadline' => get_field('deadline', get_the_ID()),
	'link' => get_the_permalink(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$location = get_the_terms( get_the_ID(), 'location' ); ?>


<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="card-content"><?php
		// location
		if(!empty($location)){ 
			$terms_location = join(' | ', wp_list_pluck($location, 'name')); 
			print_element( 'tagline', [
				'text'  => $terms_location,
				'class' => 'label',
			]);
		} 
		// salary.
		if ( $module_args['salary'] ) :
			print_element( 'tagline', [
				'text'  => $module_args['salary'],
				'class' => 'label',
			]);
		endif;
		// deadline.
		if ( $module_args['deadline'] ) :
			print_element( 'tagline', [
				'text'  => $module_args['deadline'],
				'class' => 'label',
			]);
		endif;
		// Heading.
		if ( $module_args['heading'] ) :
			print_element( 'heading',
				[
					'text'  => $module_args['heading'],
					'level' => 3,
				]
			);
		endif;

		// Content.
		if ( $module_args['excerpt'] ) :
			print_element( 'content', [
				'content' => $module_args['excerpt'],
				'class'   => [ 'card-text', 'post-excerpt' ],
			] );
		endif; ?>
	</div>
	<div class="card-footer">
		<?php
		// Link.
		if ( $module_args['link'] ) :
			print_element(
				'anchor',
				[
					'text' => 'Learn More',
					'href' => get_the_permalink(),
					'class' => 'acf-element acf-element-button has-background has-sea-green-background-color has-color-white',
				]
			);
		endif;
		?>
	</div>
</div>