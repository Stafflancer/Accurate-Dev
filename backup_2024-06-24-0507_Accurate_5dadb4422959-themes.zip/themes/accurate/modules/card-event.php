<?php
/**
 * MODULE: Card - Event
 * Template part for displaying reusable card in blocks and archives.
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-card-transparent',
		'card hover-image-zoom',
		'has-background-color',
	],
	'image'   => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
	'start_date' => get_field('start_date', get_the_ID()),
	'end_date' => get_field('end_date', get_the_ID()),
	'is_it_multiday_event' => get_field('is_it_multiday_event', get_the_ID()),
	'event_custom_cta_button_text' => get_field('event_custom_cta_button_text', get_the_ID()),
	'event_url' => get_field('event_url', get_the_ID()),
	'button'  => [
		'title'  => 'Read More',
		'url'    => get_the_permalink(),
		'target' => false,
		'class'  => [ 'stretched-link' ],
	],
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top';
$event_type = get_the_terms( get_the_ID(), 'event_type' );
$terms_event_type = join( ' | ', wp_list_pluck( $event_type, 'name' ) );  ?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="card-body">
		<div class="slider-upcoming-events-time">
			<div class="date-time"><?php
				if(!empty($module_args['start_date'])){ ?> 
					<span><?php echo date("m/d/Y", strtotime($module_args['start_date'])); ?></span><?php
					}
				if(!empty($module_args['is_it_multiday_event']) && $module_args['is_it_multiday_event'][0] == 'Yes' && !empty($module_args['end_date'])){ ?> - <span><?php echo date("m/d/Y", strtotime($module_args['end_date'])); ?></span><?php } ?>
			</div><?php
			// Heading.
			if ( $module_args['heading'] ) :
				print_element( 'heading', [
					'text'  => $module_args['heading'],
					'level' => 4,
					'class' => [ 'card-title', 'h4' ],
				] );
			endif;?>
		</div>
		<div class="card-text"><?php
			if ( ! empty( $terms_event_type ) ) {
				print_element( 'tagline', [
					'text'  => $terms_event_type,
					'class' => 'event-type',
				] );
			} ?>
			<div class="is-style-fill"><?php
				if(!empty($module_args['event_url']['url'])){
					print_element( 'anchor', [
						'text'  => $module_args['event_custom_cta_button_text'],
						'href'  => $module_args['event_url']['url'],
						'class' => 'learn-more-btn acf-element-button stretched-link has-background has-dark-pink-background-color has-color-white',
					] ); 
				} ?>
			</div>
		</div>
	</div>
</div>
