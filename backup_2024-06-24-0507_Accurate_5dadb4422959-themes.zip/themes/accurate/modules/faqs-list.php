<?php
/**
 * MODULE: FAQS
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-card-transparent',
		'card hover-image-zoom',
		'has-background-color',
	],
	'heading' => get_the_title(),
	'excerpt' => get_the_content(),
];
$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top w-100 h-100 object-cover object-center';
?>

<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="faq-data"><?php
		// Heading.
		if ( $module_args['heading'] ) : ?>
			<button class="accordion faqs-panel-heading"><?php
				print_element(
					'heading',[
						'text'  => $module_args['heading'],
						'level' => 4,
				]); ?>
			</button><?php
		endif; ?>
		<div class="panel faqs-panel-content" style="display: none;">
			<div class="pannel-in"><?php
				if ( $module_args['excerpt'] ) :
					print_element( 'content', [
						'content' => $module_args['excerpt'],
					] );
				endif;
				?>
			</div>
		</div>
	</div>
</div>
