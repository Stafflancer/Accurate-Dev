<?php
/**
 * MODULE: Buttons Group
 * Display one or multiple buttons.
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'         => [ 'acf-module', 'acf-module-buttons-group', 'd-flex', 'is-layout-flex' ],
	'buttons_group' => [],
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

if ( ! empty( $module_args['buttons_group'] ) && is_array( $module_args['buttons_group'] ) ) :
	?>
	<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php
		// Loop through our buttons array.
		$i = 0;
		foreach ( $module_args['buttons_group'] as $button ) :
			
			// Button.
			if ( ! empty( $button ) ) :
				if ( $i > 0 ) {
					$button['class'] = 'ms-2 ms-lg-3';
				}

				print_element( 'button', $button );

				$i++;
			endif;
		endforeach;
		?>
	</div>
<?php endif;