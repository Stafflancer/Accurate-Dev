<?php
/**
 * MODULE: Card - Blog
 * Template part for displaying reusable card in blocks and archives.
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-card-transparent',
		'card hover-image-zoom',
		'has-background-color',
	],
	'image'   => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID(), ] ),
	'button'  => [
		'title'  => 'Read More',
		'url'    => get_the_permalink(),
		'target' => false,
		'class'  => [ 'stretched-link' ],
	],
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top'; ?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<figure class="slider-transparent-img">
		<?php if ( ! empty( $module_args['image'] ) ) : ?>
			<?php echo wp_get_attachment_image( $module_args['image'], 'medium', array( 'class' => esc_attr( $image_class ) ) ); ?>
		<?php else: ?>
			<img class="<?php echo esc_attr( $image_class ); ?>"
			     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
			     alt="Image Placeholder" width="764" height="764" aria-hidden="true">
		<?php endif; ?>
	</figure>
	<div class="card-body">
		<div class="card-text"><?php
			// Heading.
			if ( $module_args['heading'] ) :
				print_element( 'heading', [
					'text'  => $module_args['heading'],
					'level' => 4,
					'class' => [ 'card-title', 'h4' ],
				] );
			endif;

			// Content.
			if ( $module_args['excerpt'] ) :
				print_element( 'content', [
					'content' => $module_args['excerpt'],
					'class'   => [ 'post-excerpt', 'm-0' ],
				] );
			endif; ?>
		</div>
		<div class="card-links">
			<a href="<?php echo $module_args['button']['url']; ?>" class="acf-element acf-element-anchor stretched-link"><?php echo $module_args['button']['title'].'<span> > </span>'; ?></a>
		</div>
	</div>
</div>