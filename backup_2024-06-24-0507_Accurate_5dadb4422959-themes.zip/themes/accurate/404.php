<?php
/**
 * The template for displaying 404 pages (not found).
 * @package bopper
 */

get_header();

use function BopDesign\bopper\get_main_classes;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_global_design_options;

$page_404  = get_field( 'page_404', 'option' );

if ( ! empty( $page_404 ) ) : ?>
	<section class="acf-block error-main position-relative has-text-white-color has-tagline-white-color has-heading-white-color text-center" style="background-image: url(<?php echo $page_404['background_image']; ?>);">
		<div class="container z-9">
			<div class="row justify-content-center">
				<div class="col-md-10 col-sm-12"><?php
					// Heading.
					if ( $page_404['heading'] ) :
						print_element( 'heading', [
							'text'  => $page_404['heading'].'',
							'level' => 1,
							'class' => [ 'card-title', 'h4' ],
						] );
					endif; 
					// Content.
					if ( $page_404['content'] ) :
						print_element( 'content', [
							'content' => $page_404['content'],
							'class'   => [ 'post-excerpt', 'm-0' ],
						] );
					endif; 
					if ( $page_404['buttons'] ) :
						print_module(
							'buttons-group',
							$page_404['buttons']
						);
					endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php
endif;

get_footer();