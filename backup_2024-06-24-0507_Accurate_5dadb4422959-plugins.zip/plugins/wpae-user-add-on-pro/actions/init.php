<?php

function pmue_init(){
}

?>