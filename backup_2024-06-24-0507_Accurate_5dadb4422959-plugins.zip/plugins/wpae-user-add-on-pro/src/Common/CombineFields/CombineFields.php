<?php

namespace Pmue\Common\CombineFields;


class CombineFields
{
    /**
     * @param $user
     * @param &$acfs
     * @param $implode_delimiter
     * @param $preview
     * @param $combineMultipleFieldsValue
     * @param $article
     * @param $element_name
     * @param $fieldSnipped
     */
    public function processCombineFields($user, &$acfs, $implode_delimiter, $preview, $combineMultipleFieldsValue, $article, $element_name, $fieldSnipped)
    {
    }


}